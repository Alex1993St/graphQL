<template>
    <div>
        <v-navigation-drawer fixed v-model="drawer" :class="$root.sidebarBg" class="darken-2" dark app>
            <v-toolbar flat dark :class="$root.sidebarBg" class="darken-3">
                <v-list class="pa-0">
                    <v-list-tile avatar>
                        <v-list-tile-avatar>
                            <v-icon>card_membership</v-icon>
                        </v-list-tile-avatar>
                    </v-list-tile>
                </v-list>
            </v-toolbar>
            <v-list class="pt-0" dense v-if="access">
                <v-divider></v-divider>

                <!--DASHBOARD-->
                <v-list-tile to="/dashboard">
                    <v-list-tile-action>
                        <v-icon>home</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Dashboard</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!--DASHBOARD-->

                <!-- ADMINPANEL -->
                <v-list-tile to="/admin">
                    <v-list-tile-action>
                        <v-icon>dashboard</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Panel</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- ADMINPANEL -->

                <!-- Users -->
                <v-list-tile to="/user">
                    <v-list-tile-action>
                        <v-icon>people_outline</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Users</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- Users -->

                <!-- Category -->
                <v-list-tile to="/category">
                    <v-list-tile-action>
                        <v-icon>list_alt</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Categories</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- Category -->

                <!-- ArticleQuery -->
                <v-list-tile to="/article">
                    <v-list-tile-action>
                        <v-icon>list_alt</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Articles</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- ArticleQuery -->

                <!-- Comments -->
                <v-list-tile to="/comments">
                    <v-list-tile-action>
                        <v-icon>comment</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Comments</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- Comments -->

                <v-card-text >
                    <v-treeview
                        v-model="trees"
                        :items="menu"
                        item-id="id"
                        item-text="title"
                        :open.sync="open"
                    >
                        <template slot="label" slot-scope="{ item }">
                            <a @click="createLink(item)">{{ item.title }}</a>
                        </template>
                    </v-treeview>
                </v-card-text>
            </v-list>

            <v-list class="pt-0" dense v-else="">
                <v-divider></v-divider>
                <!-- ADMINPANEL -->
                <v-list-tile to="/dashboard">
                    <v-list-tile-action>
                        <v-icon>home</v-icon>
                    </v-list-tile-action>
                    <v-list-tile-content>
                        <v-list-tile-title>Dashboard</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <!-- ADMINPANEL -->

                <v-card-text >
                    <v-treeview
                        v-model="trees"
                        :items="menu"
                        item-id="id"
                        item-text="title"
                        :open.sync="open"
                    >
                        <template slot="label" slot-scope="{ item }">
                            <a @click="createLink(item)">{{ item.title }}</a>
                        </template>
                    </v-treeview>
                </v-card-text>
            </v-list>
        </v-navigation-drawer>
        <v-toolbar fixed app light class="white">
            <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
            <v-toolbar-title v-text="title"></v-toolbar-title>
            <v-spacer></v-spacer>
            <v-menu bottom left transition="slide-y-transition">
                <v-btn slot="activator" icon>
                    <v-icon class="grey--text text--darken-1">account_circle</v-icon>
                </v-btn>
                <v-list>
                    <div v-if="user" @click="logout">
                        <v-list-tile  @click="">
                            <v-list-tile-action>
                                <v-icon>lock_open</v-icon>
                            </v-list-tile-action>
                            <v-list-tile-title>Logout</v-list-tile-title>
                        </v-list-tile>
                    </div>
                    <div v-else="">
                        <v-list-tile to="/login">
                            <v-list-tile-action>
                                <v-icon>person</v-icon>
                            </v-list-tile-action>
                            <v-list-tile-title>Login</v-list-tile-title>
                        </v-list-tile>
                    </div>
                </v-list>
            </v-menu>
        </v-toolbar>
    </div>
</template>

<script>
    export default {
        name: 'Header',
        data () {
            return {
                user: '',
                access: '',
                menu: [],
                open: [1, 2],
                trees: [],
                title: 'promo.doc',
                drawer: true,
                // admins: [
                //     ['Management', 'people_outline'],
                //     ['Settings', 'settings']
                // ],
                // cruds: [
                //     ['Create', 'add'],
                //     ['Read', 'insert_drive_file'],
                //     ['Update', 'update'],
                //     ['Delete', 'delete']
                // ]
            }
        },
        methods:{
            logout(){
                let vm = this;
                localStorage.removeItem('user');
                vm.axios.post('/api/logout').then(function(res){
                    vm.$router.push('/login');
                }).catch(function(err){
                    console.log(err);
                })
            },

            getTree(){
                let vm = this;
                axios.get('/api/category/tree').then(function(res){
                    vm.menu = res.data;
                }).catch(function(err){
                    console.log(err.message);
                    if("Request failed with status code 401" == err.message) vm.logout();
                })
            },

            createLink(item){
                let title = item.slug;
                this.$router.push('/list/' + title)
            }
        },

        created() {
            this.user =  JSON.parse(localStorage.getItem('user'));
            if(this.user.role >= 2) this.access = true;
            this.getTree();
        },

    }
</script>
