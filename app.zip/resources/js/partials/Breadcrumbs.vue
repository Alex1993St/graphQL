<template>
    <v-flex xs12>
        <v-breadcrumbs :items="$root.breadcrumbs" divider="/">
            <v-breadcrumbs-item
                slot="item"
                slot-scope="{ item }"
                exact
                :disabled="item.disabled"
                :to="item.href">
                {{ item.text }}
            </v-breadcrumbs-item>
        </v-breadcrumbs>
    </v-flex>
</template>

<script>
    export default {
        name: 'Breadcrumbs'
    }
</script>
