<template>
    <v-alert v-slot:no-results :value="true" color="error" icon="warning">
        Your search for "{{ search }}" found no results.
    </v-alert>
</template>

<script>
    export default {
        name: "warning"
    }
</script>

<style scoped></style>
