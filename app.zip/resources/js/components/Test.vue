<template>
    <div class="repos">

    </div>
</template>

<script>
    import { mapActions } from 'vuex';

    export default {
        name: "Wine",
        data: function() {
            return {
                getWines: ''
            };
        },

        computed: {
            wines () {
                 return this.$store.state.wines
            },

            articles () {
                return this.$store.state.articles
            }
        },

        created() {
        },

        beforeCreate() {
             this.$store.dispatch('fetchWines');

            // this.$store.dispatch('fetchArticles');
        },

        methods: {
          ...mapActions([
              'fetchWines',
               'fetchArticles'
          ])
        },

    };
</script>















<!--<template>-->
    <!--<div class="repos">-->

    <!--</div>-->
<!--</template>-->

<!--<script>-->


    <!--export default {-->
        <!--name: "ArticleQuery",-->
        <!--data: function() {-->
            <!--return {-->
                <!--art: []-->
            <!--};-->
        <!--},-->

        <!--created(){-->
            <!--this.axios.post('/api/wine', {-->
                <!--id: 1-->
            <!--}).then(function(e){-->
                     <!--console.log(e);-->
                 <!--})-->

            <!--this.axios.post('/graphql', {-->
                <!--query: "{wines{name, id}}"-->
            <!--}).then(function(e){-->
                <!--console.log(e);-->
            <!--})-->
            <!--this.axios.post('/graphql', {-->
                <!--query: "{wine(id:1){name, id}}"-->
            <!--}).then(function(e){-->
                <!--console.log(e);-->
            <!--})-->
        <!--},-->
    <!--};-->
<!--</script>-->

<!--<template>-->
    <!--<div>-->
        <!--<v-flex xs12 p-3>-->
            <!--<test v-on:event_child="eventChild"></test>-->
            <!--{{get_child_info}}-->
            <!--<test :value="put_to_child"></test>-->
        <!--</v-flex>-->
        <!--<div v-if="$apollo.loading">Loading..</div>-->
        <!--<div v-else>-->
            <!--<h1>Name: {{viewer.name}}</h1>-->
            <!--<p>Email: {{viewer.email }}</p>-->
        <!--</div>-->
    <!--</div>-->
<!--</template>-->

<!--<script>-->
    <!--import Test2 from './Test2';-->
    <!--import { gql } from "apollo-boost";-->

    <!--export default {-->
        <!--name: "Test",-->

        <!--apollo: {-->
            <!--//this query will update the `viewer` data property-->
            <!--viewer: {-->
                <!--query: gql`-->
        <!--{-->
          <!--viewer {-->
            <!--name-->
            <!--email-->
          <!--}-->
        <!--}`-->

            <!--}-->
        <!--},-->


        <!--data(){-->
            <!--return {-->
                <!--get_child_info:'',-->
                <!--put_to_child: 'Hello world',-->
                <!--viewer: {},-->
            <!--}-->
        <!--},-->

        <!--components:{-->
            <!--'test': Test2,-->
        <!--},-->

        <!--// created(){-->
        <!--//    console.log(this.$apollo.provider.defaultClient);-->
        <!--// },-->

        <!--methods: {-->
            <!--eventChild: function(info) {-->
                <!--this.get_child_info = info-->
            <!--},-->
        <!--},-->

    <!--}-->
<!--</script>-->

<!--<style scoped>-->

<!--</style>-->
