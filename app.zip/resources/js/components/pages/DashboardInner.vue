<template>
    <v-flex xs12 p-3>
        <v-flex xs12 md6 mb-4 offset-md3>
            <v-card class="elevation-2">
                <v-card-title>
                    <v-flex justify-between flex layout  mb-2 flex-wrap w-100>
                    <v-flex>
                        <h3 class="headline mb-0">Title: {{ article.title }}</h3>
                    </v-flex>
                        <v-flex text-right>
                            <h3 class="headline mb-2">Auth: {{ article.auth }}</h3>
                            <p>Time: {{ article.updated_at }}</p>
                        </v-flex>
                    </v-flex>
                    <div class="w-100" v-html="article.full">Text:  {{ article.full  }} </div>
                </v-card-title>
                <v-divider></v-divider>
                <v-card-actions>
                    <v-btn color="primary" @click="back">Back</v-btn>
                </v-card-actions>
            </v-card>
        </v-flex>
        <transition name="fade">
            <v-flex xs12 md6 offset-md3 >
                <ul v-if="comments && comments.length">
                    <li  v-for="(comment, idx) in comments" :key="idx">
                        <h3>User: {{ comment.name }}</h3>
                        <p>Message: {{ comment.message }} </p>
                        <p>Created: {{ comment.created_at }} </p>
                    </li>
                </ul>
            </v-flex>
        </transition>
        <v-flex xs12 md6 offset-md3>
            <v-form
                ref="form"
                v-model="valid"
                lazy-validation
            >
                <v-textarea
                    v-model="messages"
                    name="messages"
                    label="Message"
                    data-vv-name="messages"
                    required
                ></v-textarea>
                <v-btn
                    color="success"
                    @click="send"
                >
                    Send
                </v-btn>
                <v-btn
                    color="error"
                    @click="reset"
                >
                    Reset
                </v-btn>
            </v-form>
        </v-flex>
        <snackbar
            :show="snack.state"
            :text="snack.text"
            :timeout="snack.time"
            :color="snack.color"
        ></snackbar>
        <Preloader
            :value="preload.state"
            :message="preload.message"
            :progressColor="preload.color"
        ></Preloader>
    </v-flex>
</template>

<script>
    import Preloader from '../elements/preloader.vue';
    import snackbar from '../elements/snackbar.vue';

    export default {
        components: {snackbar, Preloader},
        data(){
            return {
                preload: {
                    state: false,
                    message: 'fetching data',
                    color: 'gray'
                },
                snack: {
                    state: false,
                    text: '',
                    color: 'success',
                    time: 10000
                },

                article: [],
                comments: [],
                name: '',
                email: '',
                messages: '',
                valid: false
            }
        },

        methods:{
            back(){
              this.$router.go(-1)
            },

            initialize() {
                let vm = this,
                    params = vm.$route.params.id;

                vm.preload.state = true;

                vm.axios.get('/api/article/data/' + params).then(function (res) {
                            let response = res.data;
                            vm.comments = response[0].comments;
                            vm.article = response[0];
                            if(response[0].auth[0]){
                                vm.article['auth_id'] = response[0].auth[0].id;
                                vm.article['auth'] = response[0].auth[0].name;
                            }else{
                                vm.article['auth'] = 'Anonymous';
                                vm.article['auth_id'] = 1;
                            }
                            vm.article['full'] = vm.images(response[0].full);
                            let meta = document.getElementsByTagName('meta');
                            meta["title"].content = vm.article.meta_title;
                            meta["description"].content = vm.article.meta_description;
                            meta["keywords"].content = vm.article.meta_keywords;
                            vm.preload.state = false;
                }).catch(function (err) {
                    vm.preload.state = true;
                    vm.$router.push({name: '404'});
                    console.log(err)
                })
            },

            images(full) {
                if(full){
                    return full.replace(/images/gi, '/images');
                }

            },

            send(){
                let vm = this;
                let post_id = vm.article.id;
               vm.snack.state = false;
                if(vm.messages ){
                    let user = JSON.parse(localStorage.getItem('user'));
                    vm.axios.post('/api/comment', {
                        name: user.name,
                        email: user.email,
                        message: vm.messages,
                        post_id: post_id,
                        user_id: vm.article['auth_id']
                    }).then(function () {
                        vm.reset();
                        vm.snack.state = true;
                        vm.snack.text = 'Your message checking. When we will approve you can see it';
                    }).catch(function (err) {
                        console.log(err)
                    })
                }
            },

            reset(){
                this.$refs.form.reset()
            }
        },

        created(){
            this.initialize();
            let params = this.$route.params.id;
            this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: params,
                    disabled: true
                }
            ]
        },
    }
</script>

<style lang="scss">
    .application a {
        word-break: break-all;
    }

    .fade-enter-active {
        transition: all 0.6s ease-in;
    }

    .fade-leave-active {
        transition: all 0.6s ease-in;
    }

    .fade-enter, .fade-leave-to {
        opacity: 0;
    }
</style>
