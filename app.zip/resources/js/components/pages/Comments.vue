<template>
    <v-flex xs12 p-3>
        <v-card>
            <v-toolbar flat color="white">
                <v-toolbar-title>Comments</v-toolbar-title>
                <v-spacer></v-spacer>
                <v-switch
                    v-model="switcher"
                    :label="`Status`"
                ></v-switch>
                <v-dialog v-model="dialog" max-width="500px">
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ formTitle }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container grid-list-md>
                                <v-layout wrap>
                                    <v-flex xsl2 sm12 md12>
                                        <v-text-field v-model="editedItem.message" name="message" label="Message"></v-text-field>
                                    </v-flex>
                                    <!--<v-flex xs12 sm6 md6>-->
                                        <!--<v-text-field v-model="editedItem.post_id" name="post_id" label="Post"></v-text-field>-->
                                    <!--</v-flex>-->
                                    <v-flex xs12 sm6 md6>
                                        <v-select :items="items" item-text="status" item-value="id" v-model="editedItem.status" name="status" label="Status"></v-select>
                                    </v-flex>
                                </v-layout>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" flat @click="close">Cancel</v-btn>
                            <v-btn color="blue darken-1" flat @click="save">Save</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-toolbar>
            <v-data-table
                :headers="headers"
                :items="commentsList"
                class="elevation-1"
                :loading="loading"
            >
                <template v-slot:items="props">
                    <td>{{ props.item.id }}</td>
                    <td class="text-xs-left">{{ props.item.name }}</td>
                    <td class="text-xs-left">{{ props.item.email }}</td>
                    <td class="text-xs-left">{{ props.item.message | truncate }}</td>
                    <td class="text-xs-left">{{props.item.post_id }}</td>
                    <td class="text-xs-left">{{ rewrite(props.item.status) }}</td>
                    <td class="justify-left align-center  layout px-0">
                        <v-icon
                            small
                            class="mr-2"
                            @click="editItem(props.item)"
                        >
                            edit
                        </v-icon>
                        <v-icon
                            small
                            @click="deleteItem(props.item)"
                        >
                            delete
                        </v-icon>
                    </td>
                </template>
                <warning></warning>
            </v-data-table>
        </v-card>
    </v-flex>
</template>

<script>
    import Warning from "../elements/warning.vue";
    import { mapState } from 'vuex';

    export default {
        components:{Warning},
        data(){
            return {
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                formTitle: 'Edit Comment',
                headers: [
                    { text: 'Id', align: 'left', value: 'id'},
                    { text: 'Name', value: 'name' },
                    { text: 'Email', value: 'email' },
                    { text: 'message', value: 'message' },
                    { text: 'Post', value: 'post' },
                    { text: 'status', value: 'status'},
                    { text: 'Action', sortable: false }
                ],
                comments: [],
                editedItem: {
                    name: '',
                    email: '',
                    message: '',
                    post_id: '',
                    status: '',
                },
                items: [
                    {
                        id: "0",
                        status: 'not read'
                    },
                    {
                        id: "1",
                        status: 'read'
                    }
                ],
                dialog: false,
                switcher: true,
            }
        },

        computed: {
            commentsList(){
                return this.$store.getters.COMMENTS
            },

            loading(){
                return this.$store.getters.LOAD
            },

            ...mapState(['isLoading'])
        },

        created () {
            this.getComments();

            this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: 'Comments',
                    disabled: true
                }
            ];
        },

        methods: {
            getComments(){
              return this.$store.dispatch('GET_COMMENTS')
            },

            rewrite(item){
                return item == 1 ? 'read' : 'not read';
            },

            editItem (item) {
                this.editedItem = Object.assign({}, item);
                this.dialog = true;
            },

            deleteItem (item) {
                let vm = this;
                if(confirm('Are you sure you want to delete this item?')){
                    vm.axios.delete('api/comment/' + item.id);
                    vm.delComment(item.id);
                }
            },

            delComment(id){
              return this.$store.dispatch('DELETE_COMMENT', id)
            },

            close () {
                this.dialog = false;
                setTimeout(() => {
                    this.editedItem = Object.assign({}, '');
                }, 300)
            },

            save () {
                this.close();
                this.$store.dispatch('EDIT_COMMENTS', this.editedItem)
            },

            showNotActiveStatus() {
                this.getComments();
            },

            showActiveStatus() {
                return this.$store.dispatch('GET_READ_COMMENTS')
            }

        },

        filters: {
            truncate: function(value) {
              let length = 30;
              if (value.length <= length) {
                return value;
              } else {
                return value.substring(8, length) + '...';
              }
            }
        },

        watch: {
            isLoading(newValue){
                if(newValue){
                    this.alert = true;
                }else{
                    this.alert = false;
                }
            },

            dialog (val) {
                val || this.close()
            },

            switcher(val){
                if(val) this.showNotActiveStatus();
                else this.showActiveStatus();
            }
        }
    }
</script>

<style scoped>

</style>
