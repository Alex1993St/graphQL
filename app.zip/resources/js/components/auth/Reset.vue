<template>
    <v-content>
        <v-container fluid fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12 sm8 md4>
                    <v-card class="elevation-12">
                        <v-toolbar dark color="primary">
                            <v-toolbar-title>Reset password</v-toolbar-title>
                        </v-toolbar>
                        <v-card-text>
                            <v-form
                                ref=form
                                lazy-validation
                            >
                                <v-flex>
                                    <v-text-field
                                            v-model="email"
                                            prepend-icon="email"
                                            v-validate="'required|email'"
                                            :error-messages="errors.collect('email')"
                                            data-vv-name="email"
                                            name="email"
                                            label="email"
                                    ></v-text-field>
                                </v-flex>
                                <v-flex>
                                    <v-text-field
                                        v-model="password"
                                        prepend-icon="lock"
                                        v-validate="'required|min:9'"
                                        :error-messages="errors.collect('password')"
                                        type="password"
                                        data-vv-name="password"
                                        name="password"
                                        ref="password"
                                        label="password"
                                    ></v-text-field>
                                </v-flex>
                                <v-flex>
                                    <v-text-field
                                        v-model="password_confirmation"
                                        prepend-icon="lock"
                                        v-validate="'required|confirmed:password|min:9'"
                                        :error-messages="errors.collect('password_confirmation')"
                                        type="password"
                                        data-vv-name="password_confirmation"
                                        name="password_confirmation"
                                        label="password_confirmation"
                                    ></v-text-field>
                                </v-flex>
                                <v-card-actions align-items="flex-start">
                                        <v-btn @click="formSubmit"
                                               type="submit"
                                               color="info"
                                               dark>
                                            Reset Password
                                        </v-btn>
                                        <v-btn
                                            @click="formReset"
                                            color="error"
                                            white
                                        > Reset Form</v-btn>
                                        <v-btn
                                            @click="back"
                                            color="dark"
                                            green
                                        > Login</v-btn>
                                </v-card-actions>
                            </v-form>
                        </v-card-text>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
        <snackbar
            :show="snack.state"
            :text="snack.text"
            :timeout="snack.time"
            :color="snack.color"
        ></snackbar>
    </v-content>
</template>

<script>
    import Snackbar from '../elements/snackbar.vue';

    export default {
        components: {Snackbar},
        data: () => {
            return {
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                email: '',
                password: '',
                password_confirmation: '',
                snack: {
                    state: false,
                    text: '',
                    time: 10000,
                    color: "success"
                }
            }
        },
        methods:{
            onSuccess() {
                this.snack.state = true;
                this.snack.text = 'Success update. You will redirected to login page';
            },

            formSubmit(event){
                event.preventDefault();
                let vm = this;
                vm.snack.state = false;
                vm.$validator.validateAll().then((result) => {
                    if(result){
                        vm.axios.post('/api/password/reset', {
                            email: vm.email,
                            password: vm.password,
                            password_confirmation: vm.password_confirmation,
                            token: vm.$route.params.token,
                            _token: vm.csrf
                        }).then(function(){
                            vm.formReset();
                            vm.onSuccess();
                            setTimeout(function(){
                                localStorage.removeItem('user');
                                vm.axios.post('/api/logout').then(function(){
                                    vm.$router.push('/');
                                }).catch(function(err){
                                    console.log(err);
                                })
                            }, 5000);
                        }).catch(function (err) {
                            console.log(err);
                        })
                    }
                });
            },

            formReset()
            {
                let vm = this;
                vm.$refs.form.reset();
                setTimeout(function(){
                    vm.errors.clear();
                }, 100);
            },

            back(){
                this.$router.push('/');
            }
        }
    }
</script>

<style scoped></style>
