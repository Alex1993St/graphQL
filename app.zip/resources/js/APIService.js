import axios from 'axios';

export class APIService{

    constructor(){
    }

    getCategories() {
        const url = `api/category`;
        return axios.get(url).then(response => response.data);
    }

    deleteCategory(id) {
        const url = `api/category/${id}`;
        return axios.delete(url);
    }

    getUsers() {
        const url = `api/user`;
        return axios.get(url).then(response => response.data);

    }
    deleteUser(id) {
        const url = `api/user/${id}`;
        return axios.delete(url);
    }


    getArticles() {
        const url = `api/article`;
        return axios.get(url).then(response => response.data);
    }
    deleteArticle(id) {
        const url = `api/article/${id}`;
        return axios.delete(url);
    }
}
