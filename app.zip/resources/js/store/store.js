import Vue from 'vue';
import Vuex from 'vuex';
import { apolloClient } from '../apollo';
import gql from 'graphql-tag';


Vue.use(Vuex);

const wineQuery = gql `{
    wines{
        id
        name
    },
    articles{
        id
        title
    }
    article(id: 1){
        id
        title
    }
}`;

const articleQuery = gql `{
    articles{
        id
        title
    }
}`;




const state = {
    wines: 12313123,
    articles: 12313123,
};



const mutations = {
    fetchWines (state, wines){
        state.wines = wines
    },

    fetchArticles (state, articles){
        state.articles = articles
    },
};

const actions  = {
    async fetchWines({commit}){
        const data = await apolloClient.query({query: wineQuery})
        commit('fetchWines', data.data)
    },

    async fetchArticles({commit}){
        const data = await apolloClient.query({query: articleQuery})
        commit('fetchArticles', data.data)
    },
};


export const store = new Vuex.Store({
    state,
    mutations,
    actions,
});
