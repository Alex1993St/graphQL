import Vue from 'vue';
import Vuex from 'vuex';
import { apolloClient } from '../apollo';
import gql from 'graphql-tag';


Vue.use(Vuex);

const wineQuery = gql `{
    wines{
        id
        name
    }
}`;

const articleQuery = gql `{
    articles{
        id
        title
    }
}`;


//// use it if Schema is set Mutation
// const wineMutation = gql `
//     mutation createWine(
//         $items: [String]!
//     ){
//         createWine(objects: [{items: $items}]) {
//             affected_rows
//             returning {
//                 name
//                 description
//                 color
//                 grape_variety
//                 country
//             }
//         }
// }`;

const wineMutation = gql `
    mutation wineMutation(
            $color: String!,
            $country: String!,
            $description: String!,
            $grape_variety: String!,
            $name: String!
    ){
        createWine: createWine(
            color: $color,
            country: $country,
            description: $description,
            grape_variety: $grape_variety,
            name: $name
        ) {
                name
                description
                color
                grape_variety
                country
        }
}`;

const wineMutationUpdate = gql `
    mutation wineMutationUpdate(
        $color: String!,
        $country: String!,
        $description: String!,
        $grape_variety: String!,
        $name: String!,
        $id: Int!
    ){
       updateWine: updateWine(
            color: $color,
            country: $country,
            description: $description,
            grape_variety: $grape_variety,
            name: $name,
            id: $id
       ){
            color
            country
            description
            grape_variety
            name
            id
       } 
    }
`;

const wineMutationDelete = gql `
    mutation wineMutationDelete(
        $id: Int!
    ){
       deleteWine: deleteWine(
            id: $id
       )
    } 
`;



const state = {
    wines: [],
    articles: [],
};



const mutations = {
    fetchWines (state, wines){
        state.wines = wines
    },

    fetchArticles (state, articles){
        state.articles = articles
    },

    createWine (state, wine){
        state.wines.wines.unshift(wine.createWine)
    },

    updateWine (state, wine){
        let idx = state.wines.wines.findIndex(wines => wines.id == wine.updateWine.id)
        Vue.set(state.wines.wines, idx, wine.updateWine)
    },

    deleteWine(state, wine){
        let idx = state.wines.wines.findIndex(wines => wines.id == wine.deleteWine);
        state.wines.wines.splice(idx, 1);
    }
};

const actions  = {
    async fetchWines({commit}){
        const data = await apolloClient.query({query: wineQuery})
        commit('fetchWines', data.data)
    },

    async fetchArticles({commit}){
        const data = await apolloClient.query({query: articleQuery})
        commit('fetchArticles', data.data)
    },

     // async createWine({commit}, items){
     //     const data = await apolloClient.mutate({mutation: wineMutation, variables: {items: items}})
     //     console.log(data);
     //     commit('createWine', data.data)
     // },

     async createWine({commit}, items){
        const data = await apolloClient.mutate({mutation: wineMutation, variables: {
            color: items.color,
            country: items.country,
            description: items.description,
            grape_variety: items.grape_variety,
            name: items.name
        }});
        commit('createWine', data.data)
     },

    async updateWine({commit}, items){
        const data = await apolloClient.mutate({mutation: wineMutationUpdate, variables: {
                id: items.id,
                color: items.color,
                country: items.country,
                description: items.description,
                grape_variety: items.grape_variety,
                name: items.name
            }});
        commit('updateWine', data.data)
    },

    async deleteWine({commit}, items){
        const data = await apolloClient.mutate({mutation: wineMutationDelete, variables:{
                id: items.id
            }});
        commit('deleteWine', data.data);
    }
};


export const store = new Vuex.Store({
    state,
    mutations,
    actions,
});
