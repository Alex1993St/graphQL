// import { makeExecutableSchema } from 'graphql-tools';
//
// const typeDefs = `
//   type Wines {
//     id: Int!
//     name: String
//   }
//
//   type Articles {
//     id: Int!
//     title: String
//   }
//
//   type Query {
//     wines: [Wines]
//     articles: [Articles]
//   }
//
//
// `;
//
// const resolvers = {
//     Query: {
//         wines: () => wines,
//         articles: () => articles,
//     },
// };
//
// export const schema = makeExecutableSchema({
//     typeDefs,
//     resolvers,
// });
