import Vue from 'vue';
import Vuex from 'vuex';
import {moduleUsers} from './modules/users';
import {moduleArticles} from './modules/articles';
import {moduleCategories} from './modules/categories';
import {modulesComments} from './modules/comments';

Vue.use(Vuex);


export const store = new Vuex.Store({
    modules:{
      moduleUsers,
      moduleArticles,
      moduleCategories,
      modulesComments,
    },

    state: {
        isLoading : true
    },

    getters : {
        LOAD: state => {
            return state.isLoading;
        },
    },

    mutations: {
        updateLoading(state, payload) {
            state.isLoading = payload
        },
    },
});
