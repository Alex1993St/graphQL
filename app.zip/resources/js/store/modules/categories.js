import axios from "axios";

async function update_category(payload) {
    try {
        return await axios.post('/api/category', {
            id: payload.id,
            title: payload.title,
            status: payload.status,
            parent_category: payload.parent_category
        })
    }catch (e) {
        return 'caught'
    }
}

export const moduleCategories = {
    state: {
        categories: [],
    },

    getters: {
        CATEGORIES: state => {
            return state.categories;
        },
    },

    mutations: {
        SET_CATEGORIES: (state, payload) => {
            state.categories = payload
        },

        ADD_CATEGORY: (state, payload) => {
            state.categories.push(payload)
        },

        EDIT_CATEGORY: (state, payload) => {
            const idx = state.categories.findIndex( category => category.id === payload.id)
            Vue.set(state.categories, idx, payload)
        },

        DELETE_CATEGORY: (state, payload) => {
            const idx = state.categories.findIndex( category => category.id === payload.id)
            state.categories.splice(idx, 1);
        },
    },

    actions: {
        GET_CATEGORIES: async (context, payload) => {
            await axios.get('/api/category').then(function(res){
                //vm.item = vm.category = res;
                context.commit('SET_CATEGORIES', res.data);
                context.commit('updateLoading', false);
            }).catch(function (err) {
                context.commit('updateLoading', true)
            })
        },

        SAVE_CATEGORY: async (context, payload) => {
            try{
                let data = update_category(payload);
                data.then(function (res) {
                    payload.id = res.data.id
                    context.commit('ADD_CATEGORY',  payload);
                    context.commit('updateLoading', false)
                }).catch(function () {
                    context.commit('updateLoading', true)
                })

            }catch (e) {
                context.commit('', true)
            }
        },

        EDIT_CATEGORY: (context, payload) => {
            let data = update_category(payload);
            data.then(function (res) {
                context.commit('EDIT_CATEGORY', res.data);
                context.commit('updateLoading', false);
            }).catch(function (err) {
                context.commit('updateLoading', true);
            })
        },

        DELETE_CATEGORY: async (context, payload) => {
            context.commit('DELETE_CATEGORY', payload)
        },
    },
};
