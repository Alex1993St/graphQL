import axios from "axios";
import {user_exists} from "./exists";

export const modulesComments = {
    state: {
        comments: [],
    },

    getters: {
        COMMENTS: state => {
            return state.comments;
        },
    },

    mutations: {
        SET_COMMENTS: (state, payload) => {
            state.comments = payload
        },

        EDIT_COMMENT: (state, payload) => {
            const idx = state.comments.findIndex(comment => comment.id === payload.id);
            Vue.set(state.comments, idx, payload);
        },

        DELETE_COMMENT: (state, payload) => {
            const idx = state.comments.findIndex(comment => comment.id === payload.id);
            state.comments.splice(idx, 1);
        },
    },

    actions: {
        GET_COMMENTS: async (context, payload) => {
            let user = user_exists();
            await axios.get('/api/comment/auth/' + user.id).then(function (res) {
                context.commit('SET_COMMENTS', res.data);
                context.commit('updateLoading', false)
            }).catch(function (err) {
                context.commit('updateLoading', true);
            })
        },

        GET_READ_COMMENTS: async (context, payload) => {
            let user = user_exists();
            await axios.get('/api/comment/authactive/' + user.id).then(function (res) {
                context.commit('SET_COMMENTS', res.data);
                context.commit('updateLoading', false)
            }).catch(function (err) {
                context.commit('updateLoading', true)
            })
        },

        DELETE_COMMENT: async (context, payload) => {
            context.commit('DELETE_COMMENT', payload);
        },

        EDIT_COMMENTS: async (context, payload) => {
            axios.put('/api/comment/' + payload.id, {
                message: payload.message,
                post_id: payload.post_id,
                status: payload.status,
            }).then(function(res){
                context.commit('EDIT_COMMENT', payload)
                context.commit('updateLoading', false);
            }).catch(function (err) {
                context.commit('updateLoading', true);
            })
        },
    },
};
