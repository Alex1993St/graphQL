export function  user_exists() {
    const USER_DATA =  JSON.parse(localStorage.getItem('user'));
    if(!USER_DATA) return JSON.parse(localStorage.getItem('user'));
    else return USER_DATA;
};
