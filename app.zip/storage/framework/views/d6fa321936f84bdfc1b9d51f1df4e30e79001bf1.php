<?php $__env->startSection('content'); ?>
    <reset-component></reset-component>

    
        
            
                

                
                    
                        
                            
                        
                    

                    
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OSPanel\domains\document\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>