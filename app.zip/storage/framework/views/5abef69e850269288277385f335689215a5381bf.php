<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <!-- Nav pills -->
        
            
                
            
            
                
            
            
                
                
            
            
                
            
            <li class="nav-item">
                <a class="nav-link" data-toggle="pill" href="#logout">Logout</a>
            </li>
        

        <!-- Tab panes -->
        
            
                
                

            
            
                
                
                
            
            
                
                
               
            
            
                
                
            
            
                
                
                    
                    
                
            
        
        
            
                
                    
                
            
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OS\OSPanel\domains\document\resources\views/dashboard.blade.php ENDPATH**/ ?>