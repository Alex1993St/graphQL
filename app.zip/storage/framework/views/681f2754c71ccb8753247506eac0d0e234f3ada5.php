<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW">

    <meta name="description" content="document">
    <meta name="keywords" content="document">
    <meta name="title" content="document">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito">
</head>
<body>
123132
<div id="test">
    <test></test>
</div>
</body>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</html>
<?php /**PATH D:\OS\OSPanel\domains\promo.24bio.com\resources\views/test.blade.php ENDPATH**/ ?>