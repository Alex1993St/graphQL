<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    /**
     * database info
     *
     * @var string
     */
   protected $table = 'comments';
   public $fillable = ['name', 'email', 'message', 'post_id', 'user_id', 'status'];

}
