<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Category extends Model
{
    /**
     * database info
     *
     * @var string
     */
    protected $table = 'categories';
    public $fillable = ['title', 'slug', 'status', 'parent_category'];

    /**
     * return slug by title
     *
     * @param $title
     * @return string
     */
    public static function slugAttr($title)
    {
        return str_slug($title.'-'.date('H:s:i'), '-');
    }

    /**
     * get category in article
     *
     * @param $title
     * @return mixed
     */
    public static function getAllByList($title)
    {
        return Category::where('slug', $title)->with('article')->get()->toArray();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function article()
    {
        return $this->hasMany('App\Article', 'category_id', 'id');
    }

    /**
     *create tree with parent and children inside
     *
     * @return array
     */
    public static function newGetTree()
    {
        return Cache::remember('tree', 60, function () {
            return Category::with('children')->where(['parent_category' => 0, 'status' => "1"])->get()->toArray();
        });
    }

    /**
     * create array where children in children
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function children()
    {
        return $this->hasMany(self::class, 'parent_category')->with('children');
    }
}
