<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 31.05.2019
 * Time: 13:00
 */

namespace App\GraphQL\Mutations;

use GraphQL;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Mutation;
use Illuminate\Validation\Rule;
use App\Wine;

class CreateWineMutation extends Mutation
{
    protected $attributes = [
        'name' => 'createWine'
    ];

    public function authorize(array $args)
    {
       return true;
    }

    public function rules(array $args = [])
    {
        return [
            'name' => [
                'required', 'max:50'
            ],
            'description' => [
                'required'
            ],
            'color' => [
                'required', 'max:10'
            ],
            'grape_variety' => [
                'required', 'max:50'
            ],
            'country' => [
                'required', 'max:50'
            ]
        ];
    }

    public function type()
    {
        return GraphQL::type('Wine');
    }

    public function args()
    {
        return [
            'name' => [
                'type' => Type::nonNull(Type::string()),
                'name' => 'name',
            ],
            'description' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'description',
            ],
            'color' => [
                'type' => Type::nonNull(Type::string()),
                'color' => 'color',
            ],
            'grape_variety' => [
                'type' => Type::nonNull(Type::string()),
                'grape_variety' => 'grape_variety',
            ],
            'country' => [
                'type' => Type::nonNull(Type::string()),
                'country' => 'country',
            ]
        ];
    }

    public function resolve($root, $args)
    {
        $wine = new Wine();
        $wine->fill($args);
        $wine->save();

        return $wine;
    }
}
