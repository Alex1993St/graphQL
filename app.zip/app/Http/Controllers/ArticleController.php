<?php

namespace App\Http\Controllers;

use App\Article;
use App\Wine;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Article::getTitleCat();

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function articleDetails($id)
    {
        return Article::details($id);
    }

    /**
     * @return mixed
     */
    public function articleActive($only)
    {
        return Article::getTitleCatActive($only);
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function image(Request $request)
    {
        $image = $request->file('file');

        $origin = $image->getClientOriginalName();

        $image->move('images/', $origin);

        return \Response::json(['folder' => 'images', 'location' => '/images/'.$origin]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();

       return Article::updateOrCreate(
            ['id' => $data['id']],
            [
                'title' => $data['title'],
                'status' => $data['status'],
                'slug' => Article::slugAttribute($data['title']),
                'category_id' => $data['category_id'],
                'short' => $data['short'],
                'full' => $data['full'],
                'meta_title' => $data['meta_title'],
                'meta_description' => $data['meta_description'],
                'meta_keywords' => $data['meta_keywords'],
                'only' => $data['only'],
                'user_id' => $data['user_id']
            ]
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function show(Article $article)
    {
        return Article::find($article->id)->toArray();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function edit(Article $article)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Article $article)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Article  $article
     * @return \Illuminate\Http\Response
     */
    public function destroy(Article $article)
    {
        Article::where('id', $article->id)->delete();
    }


    /**
     * @param $slug
     * Get all data by current post
     * @return mixed
     */
    public function data($slug)
    {
        return Article::getAllDataFromPost($slug);
    }

    public function wine()
    {
        return Wine::select('name', 'id')->where('id', 1)->get();
    }

}
