<?php

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/user/ip/whitelist', 'UserController@whiteList');



Route::post('/wine', 'ArticleController@wine');


Route::group(['middleware'=> 'auth'], function (){
    Route::resource('/article', 'ArticleController');
    Route::get('/article/active/{only}', 'ArticleController@articleActive');
    Route::get('/article/data/{slug}', 'ArticleController@data');
    Route::get('/article/articleDetails/{id}', 'ArticleController@articleDetails');
    Route::get('/comment/auth/{auth_id}', 'CommentController@allCommentsByAuth');
    Route::get('/comment/authactive/{auth_id}', 'CommentController@allCommentsByAuthActive');
    Route::post('/article/images', 'ArticleController@image');
    Route::get('/category/tree', 'CategoryController@tree');
    Route::get('/list/{title}', 'CategoryController@listArticle');
    Route::get('/home', 'HomeController@index')->name('home');
    Route::resource('/comment', 'CommentController');
    Route::resource('/category', 'CategoryController');
    Route::resource('/user', 'UserController');
});
