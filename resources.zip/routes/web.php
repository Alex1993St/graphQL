<?php

Route::get('/api/password/reset/{token}', 'UserController@redirectapi')->name('password.reset');


Route::get('/{any}', function(){
   return view('welcome');
})->where('any', '.*');
