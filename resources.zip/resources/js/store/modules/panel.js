import Vue from 'vue';
import Vuex from 'vuex';
import {apolloClient} from "../../apollo";
import gql from 'graphql-tag'

Vue.use(Vuex);

const panelQuery = gql `{
                        articles{
                            id
                            title
                            slug
                            status
                            only
                        },
                        category{
                            id
                            title
                            slug
                            status
                            parent_category
                        },
                        comments{
                            id
                            name
                            email
                            post_id
                        },
                        users{
                            id
                            name
                            email
                            role
                        }
                    }`;

export const modulesPanel = {
    state: {
        panel: []
    },

     mutations: {
        fetchPanel(state, data){
            state.panel = data;
        }
     },

    actions: {
        async fetchPanel({commit}){
            const data = await apolloClient.query({query: panelQuery});
            commit('fetchPanel', data.data);
        }
    }
}

