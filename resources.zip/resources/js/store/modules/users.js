import axios from "axios";

async function update(payload) {
    try {
        return await axios.post('/api/user', {
            id: payload.id,
            name: payload.name,
            email: payload.email,
            password: payload.password,
            role: payload.role
        })
    }
    catch (e) {
        return 'caught';
    }
}

export const moduleUsers = {
    state: {
        users : [],
    },

    getters: {
        USERS: state => {
            return state.users;
        },
    },

    mutations: {
        SET_USERS : (state, payload) => {
            state.users = payload
        },

        EDIT_USER: (state, payload) => {
            const idx = state.users.findIndex(user => user.id === payload.id)
            Vue.set(state.users, idx, payload)
        },

        ADD_USERS : (state, payload) => {
            state.users.push(payload)
        },

        DELETE_USER: (state, payload) => {
            const idx = state.users.findIndex(user => user.id === payload.id);
            state.users.splice(idx, 1);
        },
    },

    actions: {
        GET_USERS : async (context,payload) => {
            let { data } = await axios.get('/api/user')
            context.commit('SET_USERS',data)
            context.commit('updateLoading', false)
        },

        SAVE_USER : async (context,payload) => {
            try{
                let data  = update(payload);
                data.then(function(res){
                    payload.id = res.data.id;
                    context.commit('ADD_USERS', payload)
                    context.commit('updateLoading', false)
                }).catch(function(){
                    context.commit('updateLoading', true)
                })
            }catch (e) {
                context.commit('updateLoading', true)
            }
        },

        EDIT_USER: async (context, payload) => {
            try{
                update(payload);
                context.commit('EDIT_USER', payload)
                context.commit('updateLoading', false)
            }catch (e) {
                context.commit('updateLoading', true)
            }
        },

        DELETE_USER: (context, payload) => {
            context.commit("DELETE_USER", payload)
        },
    }
};


