import axios from "axios";
import {user_exists} from "./exists";

async function update_article(payload) {
    try {
        return await axios.post('api/article', {
            id: payload.id,
            title: payload.title,
            status: payload.status,
            category_id: payload.category_id,
            short: payload.short,
            full: payload.full,
            meta_title: payload.meta_title,
            meta_description: payload.meta_description,
            meta_keywords: payload.meta_keywords,
            only: payload.only,
            user_id: USER_DATA.id
        });
    }catch(e) {
        return 'caught';
    }
}

export const moduleArticles = {
    state: {
        articles: []
    },

    getters: {
        ARTICLES: state => {
            return state.articles;
        },
    },

    mutations: {
        SET_ARTICLES: (state, payload) => {
            state.articles = payload
        },

        EDIT_ARTICLE: (state, payload) => {
            const idx = state.articles.findIndex(article => article.id === payload.id)
            Vue.set(state.articles, idx, payload)
        },

        ADD_ARTICLE: (state, payload) => {
            state.articles.push(payload)
        },

        DELETE_ARTICLE: (state, payload) => {
            const idx = state.articles.findIndex(user => user.id === payload.id);
            state.articles.splice(idx, 1);
        },
    },

    actions: {
        GET_ARTICLES: async (context, payload) => {
            await axios.get('/api/article').then(function(res){
                const items = [];
                res.data.forEach(function(item){
                    item.category_id = item.category_id[0].id;
                    items.push(item);
                });
                context.commit('SET_ARTICLES', items);
                context.commit('updateLoading', false)
            }).catch(function(err){
                context.commit('updateLoading', true)
            })
        },

        GET_ROLE_ARTICLE: async (context, payload) => {
            let user = user_exists();

            await axios.get('/api/article/active/' + user.role).then(function(res){
                context.commit('SET_ARTICLES', res.data)
                context.commit('updateLoading', false)
            }).catch(function(err){
                context.commit('updateLoading', true)
            })
        },

        SAVE_ARTICLE: async (context, payload) => {
            let data =  update_article(payload)
            data.then(function (res) {
                payload.id = res.data.id
                context.commit('ADD_ARTICLE', payload);
                context.commit('updateLoading',false)
            }).catch(function (err) {
                context.commit('updateLoading', true)
            })
        },

        EDIT_ARTICLE: async (context, payload) => {
            try{
                update_article(payload)
                context.commit('EDIT_ARTICLE', payload);
                context.commit('updateLoading', false)
            }catch(err){
                context.commit('updateLoading', true);
            }
        },

        DELETE_ARTICLE: async (context, payload) => {
            context.commit('DELETE_ARTICLE', payload);
        },
    },
};
