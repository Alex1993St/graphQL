<template>
    <div>
        <div class="card-header">Register</div>
        <div class="card-body">
            <form method="POST" action="/register" @submit="formSubmit">
                <input type="hidden" name="_token" :value="csrf">
                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">Name</label>
                    <div class="col-md-6">
                        <input v-validate="'required|alpha'" id="name" type="text" class="form-control"  name="name" v-model="name" required autocomplete="name" autofocus>
                        <span v-show="errors.has('name')" class="help is-danger">{{ errors.first('name') }}</span>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>

                    <div class="col-md-6">
                        <input v-validate="'required|email'" id="email" type="email" class="form-control"  name="email" v-model="email" required autocomplete="email">
                        <span v-show="errors.has('email')" class="help is-danger">{{ errors.first('email') }}</span>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                    <div class="col-md-6">
                        <input ref="password" v-validate="'required'" id="password" type="password" class="form-control" name="password" v-model="password" required autocomplete="new-password">
                        <span v-show="errors.has('password')" class="help is-danger">{{ errors.first('password') }}</span>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                    <div class="col-md-6">
                        <input data-vv-as="password" v-validate="'required|confirmed:password'" id="password-confirm" type="password" class="form-control" name="password_confirmation" v-model="password_confirmation" required autocomplete="new-password">
                        <span v-show="errors.has('password_confirmation')" class="help is-danger">{{ errors.first('password_confirmation') }}</span>
                    </div>
                </div>
                <div v-if="error">
                    <span class="help is-danger">{{ error }}</span>
                </div>
                <v-card-actions class="col-md-6 offset-md-4">
                    <v-btn type="submit" color="primary">Register</v-btn>
                    <v-btn to="/dashboard" color="danger">Back</v-btn>
                </v-card-actions>
            </form>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
           return {
               csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
               name: '',
               email: '',
               password: '',
               password_confirmation: '',
               error: ''
           }
        },

        methods: {
            formSubmit(event){
                event.preventDefault();
                let vm = this;
                vm.axios.post('/api/register', {
                    name: vm.name,
                    email: vm.email,
                    password: vm.password,
                    password_confirmation: vm.password_confirmation
                }).then(function(response){
                    let data = response.data;
                    localStorage.setItem('bigStore.user', JSON.stringify(data.user))
                    localStorage.setItem('bigStore.jwt', data.token)
                    if (localStorage.getItem('bigStore.jwt') != null) {
                        this.$emit('loggedIn')
                        let nextUrl = this.$route.params.nextUrl
                        this.$router.push((nextUrl != null ? nextUrl : '/'))
                    }
                }).catch(function () {
                    vm.error = "Email is attend"
                })
            }
        }
    }
</script>

<style scoped>
    .is-danger{
        color: red;
    }
</style>
