<template>
    <v-content>
        <v-container fluid fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12 sm8 md4>
                    <v-card class="elevation-12">
                        <v-toolbar dark color="primary">
                            <v-toolbar-title>Login form</v-toolbar-title>
                        </v-toolbar>
                        <v-card-text>
                            <form method="POST" action="/login" @submit="formSubmit">
                                <input type="hidden" name="_token" :value="csrf">
                                <v-flex>
                                    <v-text-field
                                        v-model="email"
                                        prepend-icon="email"
                                        v-validate="'required|email'"
                                        :error-messages="errors.collect('email')"
                                        data-vv-name="email"
                                        id="email"
                                        name="email"
                                        label="Email Address"
                                        required autocomplete="email" autofocus
                                    >
                                    </v-text-field>
                                </v-flex>
                                <v-flex>
                                    <v-text-field
                                        v-model="password"
                                        prepend-icon="lock"
                                        v-validate="'required'"
                                        :error-messages="errors.collect('password')"
                                        data-vv-name="password"
                                        id="email"
                                        name="email"
                                        label="Password"
                                        type="password"
                                    >
                                    </v-text-field>
                                </v-flex>
                                <v-card-actions>
                                    <v-btn type="submit" @submit.prevent color="primary">Login</v-btn>
                                    <v-btn to="/email" color="danger">Forgot Password?</v-btn>
                                </v-card-actions>
                            </form>
                        </v-card-text>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
        <snackbar
            :show="snack.state"
            :text="snack.text"
            :timeout="snack.time"
        ></snackbar>
    </v-content>
</template>

<script>
    import Snackbar from '../elements/snackbar.vue';
    export default {
        components: {Snackbar},
        data(){
            return {
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                email: '',
                password: '',
                snack: {
                    state: false,
                    text: '',
                    time: 3000
                }
            }
        },

        methods:{
            formSubmit(e){
                e.preventDefault();
                let vm = this;
                vm.snack.state = false;
                axios.get('/api/user/ip/whitelist').then(function(res){
                    axios.post('api/login', {
                        email: vm.email,
                        password: vm.password
                    }).then(function (){
                        axios.get('/api/user/'+vm.email).then(function (res) {
                            let user = res.data[0];
                            if(user){
                                let is_admin = user.role;
                                localStorage.setItem('user', JSON.stringify(user))
                                if (localStorage.getItem('user') != null) {
                                    vm.$emit('loggedIn')
                                    if (vm.$route.params.nextUrl != null) {
                                        vm.$router.push(this.$route.params.nextUrl)
                                    } else {
                                        vm.$router.push('dashboard')
                                    }
                                }
                            }else{
                                vm.snack.state = true;
                                vm.snack.text = 'Checked your email and password'
                            }
                        })
                    }).catch(function () {
                        vm.snack.state = true;
                        vm.snack.text = 'Checked your email and password'
                    })
                }).catch(function(err){
                    vm.snack.state = true;
                    vm.snack.text = 'ip is not exists in white list'
                })
            },
        },
    }
</script>

<style scoped></style>
