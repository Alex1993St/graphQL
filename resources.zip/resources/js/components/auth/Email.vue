<template>
    <v-content>
        <v-container fluid fill-height>
            <v-layout align-center justify-center>
                <v-flex xs12 sm8 md4>
                    <v-card class="elevation-12">
                        <v-toolbar dark color="primary">
                            <v-toolbar-title>Reset password</v-toolbar-title>
                        </v-toolbar>
                        <v-card-text>
                            <form method="POST" action="/password/email" @submit="formSubmit">
                                <input type="hidden" name="_token" :value="csrf">
                                  <v-flex>
                                        <v-text-field
                                            v-model="email"
                                            prepend-icon="email"
                                            v-validate="'required|email'"
                                            :error-messages="errors.collect('email')"
                                            data-vv-name="email"
                                            id="email"
                                            name="email"
                                            label="Email Address"
                                            required autocomplete="email" autofocus
                                        >
                                        </v-text-field>
                                 </v-flex>
                                <div v-if="error">
                                    <span class="help is-danger">{{ error }}</span>
                                </div>
                                <div v-if="send">
                                    <span class="help is-success">{{ send }}</span>
                                </div>
                                <v-flex>
                                    <v-btn
                                        class="ml-0"
                                        type="submit"
                                        color="primary">
                                        submit
                                    </v-btn>
                                    <v-btn to="/login" color="danger">Back</v-btn>
                                </v-flex>
                            </form>
                        </v-card-text>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
        <snackbar
            :show="snack.state"
            :text="snack.text"
            :timeout="snack.time"
            :color="snack.color"
        ></snackbar>
    </v-content>
</template>


<script>
    import Snackbar from '../elements/snackbar.vue';
    export default {
        components: {Snackbar},
        data: () => {
        return {
            csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
            email: '',
            error: '',
            send: '',
            snack: {
                state: false,
                text: '',
                time: null,
                color: ""
            }
        }
    },

    methods:{
        onSuccess(){
            this.snack.state = true;
            this.snack.color = 'success';
            this.snack.time = 10000;
            this.snack.text = "We will checking your email if it be in database we send you mail with instruction";
        },

        onError() {
            this.snack.state = true;
            this.snack.color = "error";
            this.snack.time = 3000;
            this.snack.text = "Email not found";
        },

        formSubmit(e){
            e.preventDefault();
            let vm = this;
            vm.snack.state = false;
            vm.axios.post('/api/password/email', {
                email: vm.email,
                _token: vm.csrf
            }).then(function (res) {
                vm.onSuccess();
                setTimeout(function () {
                    vm.$router.push({name: 'login'})
                }, 5000);
            }).catch(function () {
                vm.onError();
            })
        }
     }
    }
</script>

<style scoped></style>
