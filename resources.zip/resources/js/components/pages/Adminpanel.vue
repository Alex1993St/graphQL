<template>
    <v-flex xs12 p-3>
        <v-flex xs12 sm12 offset-sm mb-2>
            <v-card>
                <v-toolbar color="green" dark>
                    <router-link :to="{name: 'category'}">Last add Category</router-link>
                </v-toolbar>
                <v-list two-line>
                    <template>
                        <v-data-table
                            :headers="headers_cat"
                            :items="panelList.category"
                            class="elevation-1"
                            :pagination.sync="pagination_cat"
                        >
                            <template v-slot:items="props">
                                <td>{{ props.item.id }}</td>
                                <td class="text-xs-left">{{ props.item.title }}</td>
                                <td class="text-xs-left">{{ props.item.slug }}</td>
                                <td class="text-xs-left">{{ r_status(props.item.status)}}</td>
                                <td class="text-xs-left">{{ props.item.parent_category}}</td>
                            </template>
                            <warning></warning>
                        </v-data-table>
                    </template>
                </v-list>
            </v-card>
        </v-flex>
        <v-flex xs12 sm12 offset-sm mb-2>
            <v-card>
                <v-toolbar color="red" dark>
                    <router-link :to="{name: 'article'}">Last add Article</router-link>
                </v-toolbar>
                <v-list two-line>
                    <template>
                        <v-data-table
                            :headers="headers_art"
                            :items="panelList.articles"
                            class="elevation-1"
                            :pagination.sync="pagination_art"
                        >
                            <template v-slot:items="props">
                                <td>{{ props.item.id }}</td>
                                <td class="text-xs-left">{{ props.item.title }}</td>
                                <td class="text-xs-left">{{ props.item.slug }}</td>
                                <td class="text-xs-left">{{ r_status(props.item.status)}}</td>
                                <td class="text-xs-left">{{ r_article(props.item.only)}}</td>
                            </template>
                           <warning></warning>
                        </v-data-table>
                    </template>
                </v-list>
            </v-card>
        </v-flex>
        <v-flex xs12 sm12 offset-sm mb-2>
            <v-card>
                <v-toolbar color="blue" dark>
                    <router-link :to="{name: 'comments'}">Last add Comments</router-link>
                </v-toolbar>
                <v-list two-line>
                    <template>
                        <v-data-table
                            :headers="headers_comment"
                            :items="panelList.comments"
                            class="elevation-1"
                            :pagination.sync="pagination_com"
                        >
                            <template v-slot:items="props">
                                <td>{{ props.item.id }}</td>
                                <td class="text-xs-left">{{ props.item.name }}</td>
                                <td class="text-xs-left">{{ props.item.email }}</td>
                                <td class="text-xs-left">{{ props.item.post_id}}</td>
                            </template>
                           <warning></warning>
                        </v-data-table>
                    </template>
                </v-list>
            </v-card>
        </v-flex>
        <v-flex xs12 sm12 offset-sm>
            <v-card>
                <v-toolbar color="orange" dark>
                    <router-link :to="{name: 'user'}">User</router-link>
                </v-toolbar>
                <v-list two-line>
                    <template>
                        <v-data-table
                            :headers="headers_us"
                            :items="panelList.users"
                            class="elevation-1"
                            :pagination.sync="pagination_us"
                        >
                            <template v-slot:items="props">
                                <td>{{ props.item.id }}</td>
                                <td class="text-xs-left">{{ props.item.name }}</td>
                                <td class="text-xs-left">{{ props.item.email }}</td>
                                <td class="text-xs-left">{{ r_role(props.item.role)}}</td>
                            </template>
                            <warning></warning>
                        </v-data-table>
                    </template>
                </v-list>
            </v-card>
        </v-flex>
    </v-flex>
</template>

<script>
    import Warning from "../elements/warning.vue";

    export default {
        components: {Warning},
        data(){
            return {
                preload: {
                    state: true,
                    message: 'fetching data',
                    color: 'gray'
                },
                pagination_cat: {
                    descending: true,
                },
                pagination_art: {
                    descending: true,
                },
                pagination_com: {
                    descending: true,
                },
                pagination_us: {
                    descending: true,
                },
                // article: [],
                // category: [],
                // comments: [],
                // users: [],
                headers_cat: [
                    {text: 'Id', value: 'id', sort: 'desc'},
                    {text: 'Title', value: 'title'},
                    {text: 'Slug', value: 'slug'},
                    {text: 'Status', value: 'status'},
                    {text: 'Parent cat', value: 'parent_category'}
                ],
                headers_art: [
                    {text: 'Id', value: 'id', sort: 'desc'},
                    {text: 'Title', value: 'title'},
                    {text: 'Slug', value: 'slug'},
                    {text: 'Status', value: 'status'},
                    {text: 'Only', value: 'only'}
                ],
                headers_us:[
                    {text: 'id', value: 'id', sort: 'desc'},
                    {text: 'Name', value: 'name'},
                    {text: 'Email', value: 'email'},
                    {text: 'Role', value: 'role'}
                ],
                headers_comment: [
                    {text: 'Id', value: 'id', sort: 'desc'},
                    {text: 'Name', value: 'name'},
                    {text: 'Email', value: 'email'},
                    {text: 'post', value: 'post'}
                ],
            }
        },
        created(){
            // this.getCategories();
            //
            // this.getArticles();
            //
            // this.getUsers();
            //
            // this.getComments();

            this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: 'Panel',
                    disabled: true
                }
            ];

            this.getPanel();
        },

        computed: {
            // categoryList(){
            //     return this.$store.getters.CATEGORIES
            // },
            //
            // articleList(){
            //     return this.$store.getters.ARTICLES
            // },
            //
            // userList(){
            //     return this.$store.getters.USERS
            // },
            //
            // commentList(){
            //
            //     return this.$store.getters.COMMENTS
            // },

            panelList(){
                return this.$store.state.modulesPanel.panel
            }
        },

        methods: {
            getPanel(){
               this.$store.dispatch('fetchPanel');
            },

            // getCategories(){
            //     return this.$store.dispatch('GET_CATEGORIES')
            // },
            //
            // getArticles(){
            //     return this.$store.dispatch('GET_ARTICLES')
            // },
            //
            // getUsers(){
            //     return this.$store.dispatch('GET_USERS')
            // },
            //
            // getComments(){
            //     return this.$store.dispatch('GET_COMMENTS')
            // },

            r_role(item){
                switch (item) {
                    case 0: return 'user';
                    case 1: return 'vip';
                    case 2: return 'author';
                    case 3: return 'admin';
                }
            },

            r_status(item) {
                return item ? 'active' : 'not active'
            },

            r_article(item){
                return item ? 'vip' : 'user'
            }
        }
    }
</script>

<style scoped>

</style>
