<template>
   <v-flex xs12 p-3>
       <v-card>
           <v-card-title>
               Dashboard
               <v-spacer></v-spacer>
               <v-text-field
                   v-model="search"
                   append-icon="search"
                   label="Search"
                   single-line
                   hide-details
               ></v-text-field>
           </v-card-title>
           <v-data-table
               :headers="headers"
               :items="articleList"
               :search="search"
               :rows-per-page-items = "rppi"
               :pagination.sync = 'pagination'
               :loading="loading"
           >
               <template v-slot:items="props">
                   <td>{{ props.item.id }}</td>
                   <td>{{ props.item.title }}</td>
                   <td>{{ rewrite_cat(props.item.category_id) }}</td>
                   <td v-html="props.item.short">{{ props.item.short }}</td>
                   <td>
                       <a>
                           <v-icon
                               small
                               class="mr-2"
                               @click="readMore(props.item.slug)"
                           >
                               more
                           </v-icon>
                       </a>
                   </td>
               </template>
                <warning></warning>
           </v-data-table>
       </v-card>
       <Preloader
           :value="preload.state"
           :message="preload.message"
           :progressColor="preload.color"
       ></Preloader>
   </v-flex>
</template>

<script>
    import Preloader from '../elements/preloader.vue';
    import Warning from '../elements/warning.vue';
    import { mapState } from 'vuex';

    export default {
        components: {Preloader, Warning},
        data(){
            return {
                rppi: [10,20,30,40,50],
                pagination:{
                  descending: true
                },
                preload: {
                    state: false,
                    message: 'fetching data',
                    color: 'gray'
                },
                search: '',
                headers: [
                    {text: 'Id', value: 'id'},
                    {text: 'Title', value: 'title'},
                    {text: 'Category_id', value: 'category_id'},
                    {text: "Short", value: 'short', sortable: false},
                    {text: "Action", value: 'action', sortable: false}
                ],
                editedIndex: {
                    id: '',
                    title: '',
                    status: '',
                    slug: '',
                    category_id: '',
                    short: '',
                    only: ''
                },
                articles: [],
            }
        },

        computed: {
            articleList(){
                return this.$store.getters.ARTICLES;
            },

            loading(){
                return this.$store.getters.LOAD
            },

            ...mapState(['isLoading'])
        },

        watch: {
            isLoading(newValue){
                if(newValue){
                    this.alert = true;
                }else{
                    this.alert = false;
                }
            },
        },

        methods:{
            getArticle(){
                return this.$store.dispatch('GET_ROLE_ARTICLE')
            },

            rewrite_cat(item){
                if(item[0]) return item[0].title;
            },

            readMore(item){
                let vm = this;
                vm.preload.state = true;
                vm.$router.push('dashboard/' + item );
            }
        },

        created(){
            this.getArticle();
            this.$root.breadcrumbs = [];
        },
    }
</script>

<style scoped lang="scss"></style>
