<template>
    <v-flex xs12 p-3>
        <v-card>
            <v-toolbar flat color="white">
                <v-toolbar-title>Users</v-toolbar-title>
                <v-spacer></v-spacer>
                <v-dialog v-model="dialog" max-width="500px">
                    <template v-slot:activator="{ on }">
                        <v-btn color="primary" dark class="mb-2" v-on="on">New User</v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ formTitle }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container grid-list-md>
                                <v-layout wrap>
                                    <v-flex xsl2 sm6 md6>
                                        <v-text-field v-validate="'required|alpha'" v-model="editedItem.name" data-vv-name="name" name="name" label="Name" :error-messages="errors.collect('name')"></v-text-field>
                                    </v-flex>
                                    <v-flex xsl2 sm6 md6>
                                        <v-text-field v-validate="'required|email'" v-model="editedItem.email" data-vv-name="email" name="email" label="Email" :error-messages="errors.collect('email')"></v-text-field>
                                    </v-flex>
                                    <v-flex xsl2 sm6 md6>
                                        <v-text-field :type="'password'" v-validate="'required'" ref="password" v-model="editedItem.password" data-vv-name="password" name="password" label="Password"  :error-messages="errors.collect('password')"></v-text-field>
                                    </v-flex>
                                    <v-flex xsl2 sm6 md6>
                                        <v-text-field :type="'password'" v-validate="'required|confirmed:password'" v-model="editedItem.password_confirmed"   data-vv-as="password" name="password_confirmed" label="Password Confirmed" data-vv-name="password_confirmed" :error-messages="errors.collect('password_confirmed')"></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm6 md4>
                                        <v-select v-validate="'required'"  item-text="role" item-value="id" :items="items" v-model="editedItem.role"  label="Role" name="role" data-vv-name="role" :error-messages="errors.collect('role')"></v-select>
                                    </v-flex>
                                </v-layout>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" flat @click="close">Cancel</v-btn>
                            <v-btn color="blue darken-1" flat @click="save">Save</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-toolbar>
            <v-alert
                :value="alert"
                type="error"
            >
                User is already exists
            </v-alert>
            <v-data-table
                :headers="headers"
                :items="usersList"
                class="elevation-1"
                :loading="loading"
            >
                <template v-slot:items="props">
                    <td>{{ props.item.id }}</td>
                    <td class="text-xs-left">{{ props.item.name }}</td>
                    <td class="text-xs-left">{{ props.item.email }}</td>
                    <td class="text-xs-left">{{ rewrite(props.item.role)}}</td>
                    <td class="justify-left align-center  layout px-0">
                        <v-icon
                            small
                            class="mr-2"
                            @click="editItem(props.item)"
                        >
                            edit
                        </v-icon>
                        <v-icon
                            small
                            @click="deleteItem(props.item)"
                        >
                            delete
                        </v-icon>
                    </td>
                </template>
                <warning></warning>
            </v-data-table>
        </v-card>
    </v-flex>
</template>
<script>
    import {APIService} from '../../APIService';
    import Warning from '../elements/warning.vue';
    import { mapState } from 'vuex';
    import {mapActions} from 'vuex';

    const apiService = new APIService();
    export default {
        components:{Warning},
        data(){
            return{
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                headers: [
                    { text: 'id', align: 'left', value: 'id'},
                    { text: 'Name', value: 'name' },
                    { text: 'Email', value: 'email' },
                    { text: 'Role', value: 'role' },
                    { text: 'Actions', value: 'name', sortable: false }
                ],
                users: [],
                editedItem: {
                    name: '',
                    email: '',
                    password: '',
                    password_confirmed: '',
                    role: [],
                },
                items: [
                    {
                        id: 0,
                        role: 'user'
                    },
                    {
                        id: 1,
                        role: 'business'
                    },
                    {
                        id: 2,
                        role: 'author'
                    },
                    {
                        id: 3,
                        role: 'admin'
                    },
                ],
                userRole: '',
                dialog: false,
                editedIndex: -1,
                alert: false
            }
        },

        computed: {
            formTitle () {
                return this.editedIndex === -1 ? 'New User' : 'Edit User';
            },

            loading(){
                return this.$store.getters.LOAD
            },

            usersList(){
                return this.$store.getters.USERS
            },

            ...mapState(['isLoading'])
        },

        watch: {
            isLoading(newValue){
                if(newValue){
                    this.alert = true;
                }else{
                    this.alert = false;
                }
            },

            dialog (val) {
                val || this.close()
            },
        },

        created () {
            this.getUsersList();

            this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: 'Users',
                    disabled: true
                }
            ];
        },

        methods: {
            ...mapActions(['SAVE_USER', 'EDIT_USER', 'DELETE_USER']),

            // DELETE_USER(id) {
            //     this.$store.dispatch("DELETE_USER", id);
            // },

            getUsersList(){
                return this.$store.dispatch('GET_USERS');
            },

            rewrite(item){
                switch (item) {
                    case 0:  return 'user';
                    case 1:  return 'business';
                    case 2:  return 'author';
                    case 3:  return 'admin';
                    default:  return 'error';
                }
            },

            editItem (item) {
                this.editedIndex = 1;
                this.editedItem = Object.assign({}, item);
                this.dialog = true;
            },

            deleteItem (item) {
                let vm = this;
                if(confirm('Are you sure you want to delete this item?')){
                    apiService.deleteUser(item.id).then((r)=>{
                        if(r.status === 200){vm.DELETE_USER(item.id);}
                    })
                }
            },

            // saveUser() {
            //     return this.$store.dispatch('SAVE_USER', this.editedItem)
            // },
            //
            // editUser() {
            //     return this.$store.dispatch('EDIT_USER', this.editedItem)
            // },


            close () {
                this.dialog = false
                setTimeout(() => {
                    this.editedItem = Object.assign({}, this.defaultItem)
                    this.editedIndex = -1
                }, 300)
            },

            save () {
                let vm = this;
                vm.editedItem.id ? vm.editedItem.id : vm.editedItem.id = '';
                vm.$validator.validateAll().then((result) => {
                    if(result) {
                        vm.close();
                        vm.editedIndex === -1 ?
                            vm.SAVE_USER(vm.editedItem)
                            :
                            vm.EDIT_USER(vm.editedItem);
                        //vm.editedIndex === -1 ? vm.saveUser() : vm.editUser();
                    }
                })
            }
        }
    }
</script>
