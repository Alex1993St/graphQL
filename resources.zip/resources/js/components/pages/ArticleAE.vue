<template>
    <v-flex container>
        <form ref="form">
            <v-text-field
                v-validate="'required'"
                label="Title"
                v-model="article.title"
                data-vv-name="title"
                name="title"
                :error-messages="errors.collect('title')"
            ></v-text-field>
            <v-select
                v-validate="'required'"
                label="Status"
                :items="status"
                item-text="text"
                item-value="value"
                v-model="article.status"
                name="status"
                data-vv-name="status"
                :error-messages="errors.collect('status')"
            ></v-select>
            <v-select
                name="category_id"
                data-vv-name="category_id"
                v-validate="'required'"
                label="Category id"
                v-model="article.category_id"
                :items="categories"
                item-text="title"
                item-value="id"
                :error-messages="errors.collect('category_id')"
            ></v-select>
            <v-text-field
                name="short"
                data-vv-name="short"
                v-validate="'required'"
                label="Short"
                v-model="article.short"
                :error-messages="errors.collect('short')"
            ></v-text-field>
                <editor api-key="k8su65qufq3jlepq1on0czt8zlo25lfht4h9n0xbbx320is0"
                        :plugins="myPlugins"
                        :toolbar ="myToolbar1"
                        :init="myInit"
                        v-validate="'required'"
                        v-model="article.full"
                        data-vv-name="full"
                        name="full"
                        label="Full"
                        :error-messages="errors.collect('full')"
                        cloud-channel='stable'
                ></editor>
            <v-text-field
                v-validate="'required'"
                label="Meta title"
                v-model="article.meta_title"
                name="meta_title"
                data-vv-name="meta_title"
                :error-messages="errors.collect('meta_title')"
            ></v-text-field>
            <v-text-field
                v-validate="'required'"
                label="Meta description"
                v-model="article.meta_description"
                name="meta_description"
                data-vv-name="meta_description"
                :error-messages="errors.collect('meta_description')"
            ></v-text-field>
            <v-text-field
                v-validate="'required'"
                label="Meta Keywords"
                v-model="article.meta_keywords"
                name="meta_keywords"
                data-vv-name="meta_keywords"
                :error-messages="errors.collect('meta_keywords')"
            ></v-text-field>
            <v-select
                name="only"
                data-vv-name="only"
                v-validate="'required'"
                label="Access"
                v-model="article.only"
                :items="access"
                item-text="text"
                item-value="value"
                :error-messages="errors.collect('only')"
            ></v-select>
            <v-btn @click="submit" color="success" dark class="mb-2">submit</v-btn>
            <v-btn @click="clear" color="danger" dark class="mb-2">clear</v-btn>
            <v-btn @click="back" color="info" dark class="mb-2">back</v-btn>
        </form>

        <Preloader
            :value="preload.state"
            :message="preload.message"
            :progressColor="preload.color"
        ></Preloader>
        <snackbar
            :show="snack.state"
            :text="snack.text"
            :timeout="snack.time"
            :color="snack.color"
        ></snackbar>
    </v-flex>
</template>

<script>
    import Editor from '@tinymce/tinymce-vue';
    import Preloader from '../elements/preloader.vue';
    import snackbar from '../elements/snackbar.vue';

    export default {
      data() {
          return {
              article: {},
              status:[
                    {text: 'active', value: "1"},
                    {text: 'not active', value: "0"}
              ],
              preload: {
                  state: true,
                  message: 'fetching data',
                  color: 'gray'
              },
              snack: {
                  state: false,
                  text: '',
                  color: 'success',
                  time: 3000
              },
              access:[
                  {text: 'all', value: '0'},
                  {text: 'vip', value: '1'}
              ],
              auth: JSON.parse(localStorage.getItem('user')),
              categories: [],
              myToolbar1: 'undo redo | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | hr bullist numlist outdent indent | link image table | code preview',
              myPlugins: 'link image code preview imagetools table lists textcolor hr wordcount',
              myInit: {
                  images_upload_handler: function (blobInfo, success, failure) {
                      var xhr, formData;
                      xhr = new XMLHttpRequest();
                      xhr.withCredentials = false;

                      xhr.open('POST', '/api/article/images');
                      var token = document.head.querySelector("[name=csrf-token]").content;
                      xhr.setRequestHeader("X-CSRF-Token", token);

                      xhr.onload = function () {
                          var json;

                          if (xhr.status != 200) {
                              failure('HTTP Error: ' + xhr.status);
                              return;
                          }

                          json = JSON.parse(xhr.responseText);

                          if (!json || typeof json.location != 'string') {
                              failure('Invalid JSON: ' + xhr.responseText);
                              return;
                          }
                          success(json.location);
                      };
                      formData = new FormData();
                      formData.append('file', blobInfo.blob(), blobInfo.filename());
                      xhr.send(formData);
                  }
              },
          }
      },

       components: {
           'editor': Editor,
            Preloader,
            snackbar
       },

      created(){
         this.getArticle();
         this.getCategory();
      },


      methods:{
          getArticle(){
              let vm = this;
              let params = vm.$route.params;
              if('addNewArticle' !== params.id){
                  vm.axios.get('/api/article/articleDetails/' + params.id).then(function(res){
                      vm.article = res.data[0];
                      vm.article.category_id = res.data[0].category_id[0].id;
                  }).catch(function(err){
                      console.log(err)
                  });
              }
          },

          getCategory(){
              let vm = this
              vm.axios.get('/api/category').then(function(res){
                  vm.categories = res.data;
                  vm.preload.state = false;
              }).catch(function(err){
                  console.log(err)
              })
          },

          submit(){
                let vm = this;
                 vm.$validator.validateAll().then(function(res){
                     if(res){
                         vm.article.id ? vm.article.id : vm.article.id = '';
                         vm.axios.post('/api/article', {
                             id: vm.article.id,
                             title: vm.article.title,
                             status: vm.article.status,
                             category_id: vm.article.category_id,
                             short: vm.article.short,
                             full: vm.article.full,
                             meta_title: vm.article.meta_title,
                             meta_description: vm.article.meta_description,
                             meta_keywords: vm.article.meta_keywords,
                             only: vm.article.only,
                             user_id: vm.auth.id
                         }).then(function(res){
                             vm.snack.state = true;
                             vm.snack.color = 'success';
                             vm.snack.text = 'Success';
                             setTimeout(function(){
                                 vm.$router.push('/article');
                             }, 3000)
                         }).catch(function(err){
                             console.log(err)
                         })
                     }else{
                         vm.snack.state = true;
                         vm.snack.color = 'danger';
                         vm.snack.text = 'Error';
                     }
                 }).catch(function(err){
                     console.log(err);
                 })
          },

          clear(){
               this.$refs.form.reset();
          },

          back(){
              this.$router.go(-1)
          }
      }
  }
</script>

<style scoped>

</style>
