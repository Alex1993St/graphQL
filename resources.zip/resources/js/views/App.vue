<template>
    <v-app v-cloak>
        <router-view/>
    </v-app>
</template>

<script>
    export default {}
</script>

<style scoped>
    [v-cloak] {
        display: none;
    }
</style>
