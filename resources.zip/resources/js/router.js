import Vue from 'vue';
import Router from 'vue-router';

// Components
import Home from './components/pages/Home';
import Admin from './components/pages/Adminpanel';
import Dashboard from './components/pages/Dashboard';
import DashboardInner from './components/pages/DashboardInner';
import Article from './components/pages/Article';
import Category from './components/pages/Category';
import User from './components/pages/User';
import List from './components/pages/List';
import Comments from './components/pages/Comments';
import ArticleAE from './components/pages/ArticleAE';


// Components auth
import Login from './components/auth/Login';
// import Reqister from './components/auth/Register';
import Reset from './components/auth/Reset';
import Email from './components/auth/Email';
// 404
import Error from './components/auth/Error';

import Test from './components/Test';


Vue.use(Router)

const router = new Router({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'Home',
            component: Home,
            redirect: '/dashboard',
            children: [
                {
                    path: '/admin',
                    name: 'admin',
                    component: Admin,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/dashboard',
                    name: 'dashboard',
                    title: 'dashboard',
                    component: Dashboard,
                    meta: {
                        requiresAuth: true
                    }

                },
                {
                    path: '/dashboard/:id',
                    name: 'dashboardInner',
                    title: 'dashboardInner',
                    component: DashboardInner,
                    meta: {
                        requiresAuth: true
                    }

                },

                {
                    path: '/category',
                    name: 'category',
                    title: 'category',
                    component: Category,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/user',
                    name: 'user',
                    component: User,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/article',
                    name: 'article',
                    component: Article,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/article/:id',
                    name: 'articleAE',
                    component: ArticleAE,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/comments',
                    name: 'comments',
                    component: Comments,
                    meta: {
                        requiresAuth: true,
                        role: true
                    }
                },
                {
                    path: '/list/:title',
                    name: 'list',
                    component: List,
                    meta: {
                        requiresAuth: true,
                    }
                },
                {
                    path: '/test',
                    name: 'test',
                    component: Test,
                    meta: {
                        requiresAuth: true,
                    }
                },
            ]
        },
        {
            path: '/login',
            name: 'login',
            component: Login
        },
        // {
        //     path: '/register',
        //     name: 'register',
        //     component: Reqister,
        //     meta: {
        //         requiresAuth: true,
        //         role: true
        //     }
        // },
        {
            path: '/email',
            name: 'email',
            component: Email
        },
        {
            path: '/password/reset/:token',
            name: 'reset',
            component: Reset
        },
        {
            path: '*',
            name: '404',
            component: Error
        }

    ]
});

router.beforeEach((to, from, next) => {
    if (to.matched.some(record => record.meta.requiresAuth)) {
        let user = JSON.parse(localStorage.getItem('user'));
        if(!user){
            next({ name: 'login' })
        }
        if (to.matched.some(record => record.meta.role)) {

            if (user.role >= 2) {
                next()
            }
            else {
                next({ name: 'login' })
            }
        }
        else if (to.matched.some(record => record.meta.role)) {

            if (user.role < 2) {
                next()
            }
            else {
                next({ name: 'dashboard' })
            }
        }
        next()
    } else {
        next()
    }
});

export default router;

