<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wine extends Model
{
    protected $fillable = [
        'name', 'description', 'color', 'grape_variety', 'country',
    ];
}
