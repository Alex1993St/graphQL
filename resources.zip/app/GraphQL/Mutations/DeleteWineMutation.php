<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 31.05.2019
 * Time: 13:00
 */

namespace App\GraphQL\Mutations;

use GraphQL;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Mutation;
use App\Wine;

class DeleteWineMutation extends Mutation
{
    protected $attributes = [
        'name' => 'deleteWine',
        'description' => 'delete a wine'
    ];

    public function authorize(array $args)
    {
        return true;
    }

    public function type()
    {
        return Type::int();
    }

    public function rules(array $args = [])
    {
        return [
            'id' => [
                'required', 'numeric', 'min:1', 'exists:wines,id'
            ]
        ];
    }

    public function args()
    {
        return [
            'id' => [
                'name' => 'id',
                'type' => Type::nonNull(Type::int())
            ]
        ];
    }

    public function resolve($root, $args)
    {

        $wine = Wine::findOrFail($args['id']);
        $wine->delete() ? true : false;
        return $args['id'];
    }
}
