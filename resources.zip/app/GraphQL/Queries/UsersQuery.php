<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 04.06.2019
 * Time: 10:14
 */

namespace App\GraphQL\Queries;

use App\User;
use GraphQL;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Query;

class UsersQuery extends Query
{
    protected $attributes = [
        'name' => 'users'
    ];

    public function type()
    {
        return Type::listOf(GraphQL::type('User'));
    }

    public function resolve($root, $args)
    {
        return User::all();
    }
}
