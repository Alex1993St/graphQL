<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 31.05.2019
 * Time: 12:29
 */

namespace App\GraphQL\Queries;

use App\Article;
use GraphQL;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Query;

class ArticlesQuery extends Query
{
    protected $attributes = [
        'name' => 'articles',
    ];

    public function type()
    {
        return Type::listOf(GraphQL::type('Article'));
    }

    public function resolve($root, $args)
    {
        return Article::all();
    }
}
