<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 04.06.2019
 * Time: 10:14
 */

namespace App\GraphQL\Queries;

use App\Comment;
use GraphQL;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Query;

class CommentsQuery extends Query
{
    protected $attributes = [
        'name' => 'comments'
    ];

    public function type()
    {
       return Type::listOf(GraphQL::type('Comment'));
    }

    public function resolve($root, $args)
    {
        return Comment::all();
    }
}
