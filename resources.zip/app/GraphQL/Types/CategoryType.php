<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 04.06.2019
 * Time: 10:25
 */

namespace App\GraphQL\Types;

use App\Category;
use Rebing\GraphQL\Support\Type as GraphQLType;
use GraphQL\Type\Definition\Type;

class CategoryType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Category',
        'description' => 'About category',
        'model' => Category::class
    ];

    public function fields()
    {
        return [
            'id' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'id category'
            ],
            'title' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'title category'
            ],
            'slug' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'slug category'
            ],
            'status' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'status category'
            ],
            'parent_category' => [
                 'type' => Type::nonNull(Type::int()),
                'description' => 'parent category'
            ]
        ];
    }
}
