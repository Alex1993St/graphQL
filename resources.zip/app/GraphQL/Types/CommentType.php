<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 04.06.2019
 * Time: 10:24
 */

namespace App\GraphQL\Types;

use App\Comment;
use Rebing\GraphQL\Support\Type as GraphQLType;
use GraphQL\Type\Definition\Type;

class CommentType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Comment',
        'description' => 'About comment',
        'model' => Comment::class
    ];

    public function fields()
    {
        return [
            'id' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'id comment',
            ],
            'name' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'name comment'
            ],
            'email' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'email comment'
            ],
            'post_id' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'post comment'
            ]
        ];
    }
}
