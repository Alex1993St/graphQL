<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 04.06.2019
 * Time: 10:24
 */

namespace App\GraphQL\Types;

use App\User;
use Rebing\GraphQL\Support\Type as GraphQLType;
use GraphQL\Type\Definition\Type;

class UserType extends GraphQLType
{
    protected $attributes = [
        'name' => 'User',
        'description' => 'Detail about user',
        'model' => User::class
    ];

    public function fields()
    {
       return [
           'id' => [
               'type' => Type::nonNull(Type::int()),
               'description' => 'id of user'
           ],
           'name' => [
                'type' => Type::nonNull(Type::string()),
               'description' => 'name of user'
           ],
           'email' => [
               'type' => Type::nonNull(Type::string()),
               'description' => 'email of user'
           ],
           'role' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'role of user'
           ],

       ];
    }
}
