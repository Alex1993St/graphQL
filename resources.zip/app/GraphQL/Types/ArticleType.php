<?php
/**
 * Created by PhpStorm.
 * User: programist_1
 * Date: 31.05.2019
 * Time: 12:31
 */

namespace App\GraphQL\Types;

use App\Article;
use GraphQL\Type\Definition\Type;
use Rebing\GraphQL\Support\Type as GraphQLType;

class ArticleType extends GraphQLType
{
    protected $attributes = [
        'name' => 'Article',
        'description' => 'Details about a article',
        'model' => Article::class
    ];

    public function fields()
    {
        return [
            'id' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'Id of the article',
            ],
            'title' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The title of the article',
            ],
            'status' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'status of the article',
            ],
            'slug' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The slug of the article',
            ],
            'category' => [
                'type' => Type::nonNull(Type::int()),
                'description' => 'category of the article',
            ],
            'short' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The short of the article',
            ],
            'full' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The full of the article',
            ],
            'only' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The only of the article'
            ],
            'meta_title' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The meta_title of the article',
            ],
            'meta_description' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The meta_description of the article',
            ],
            'meta_keywords' => [
                'type' => Type::nonNull(Type::string()),
                'description' => 'The meta_keywords of the article',
            ],
        ];
    }
}
