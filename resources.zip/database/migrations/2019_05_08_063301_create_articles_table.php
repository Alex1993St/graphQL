<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticlesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('articles', function (Blueprint $table) {
            $table->integer('id', TRUE);
            $table->string('title', 250);
            $table->enum('status', [0,1]);
            $table->string('slug')->unique();
            $table->integer('category', FALSE, TRUE);
            $table->text('short');
            $table->mediumText('full');
            $table->string('meta_title', 250);
            $table->string('meta_description', 250);
            $table->string('meta_keywords', 250);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('articles');
    }
}
