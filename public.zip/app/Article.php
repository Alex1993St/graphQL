<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Intervention\Image\Facades\Image;

class Article extends Model
{
    /**
     * database info
     *
     * @var string
     */
    protected $table = 'articles';
    public $fillable = ['title', 'status', 'slug', 'category_id', 'short', 'full', 'meta_title', 'meta_description', 'meta_keywords', 'only', 'user_id'];

    /**
     * return slug by title
     *
     * @param $value
     * @return string
     */
    public static function slugAttribute($value)
    {
        return  str_slug($value.'-'.date("H:i:s"), '-');
    }

    /**
     * @return array
     */
    public static function getTitleCat()
    {
        return Article::with('category_id')->getArr();
    }

    /**
     * @param $id
     * @return mixed
     */
    public static function details($id)
    {
        return Article::where('id', $id)->with('category_id')->getArr();
    }

    /**
     * return article by status active / not active
     * @param $only
     * @return mixed
     */
    public static function getTitleCatActive($only)
    {
          $query = self::class;
          $where = $query::where(['status' => "1"]);
          if($only == 0){
              $where = $where->where(['only' => "0"]);
          }else{
              $where = $where->whereIn('only', ["0","1"]);
          }
         return $where->with('category_id')->getArr();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function category_id()
    {
        return $this->hasMany('App\Category', 'id', 'category_id')->select('id', 'title');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function auth()
    {
        return $this->hasMany('App\User', 'id', 'user_id')->select('id', 'name');
    }

    /**
     * @param $query
     * @return mixed
     */
    public function scopeGetArr($query)
    {
        return $query->get()->toArray();
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function comments()
    {
        return $this->hasMany('App\Comment', 'post_id', 'id')->select('id', 'post_id', 'name', 'message', 'created_at', 'status')->where('status', "1");
    }

    public static function getAllDataFromPost($slug)
    {
        return Article::where('slug', $slug)->with('comments', 'auth')->getArr();
    }
}
