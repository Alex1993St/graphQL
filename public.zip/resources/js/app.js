/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

import Vue from 'vue'
import VeeValidate from 'vee-validate';
import Vuetify from 'vuetify';
import axios from 'axios';
import VueAxios from 'vue-axios';
import Editor from '@tinymce/tinymce-vue';
import App from './views/App';
// import {store} from './store/index';
import router from './router';



// Apollo !!!!!!!!!!!!!!!!!!!!!!!!
import apolloProvider from './apollo'
import {store} from './store/store'
// End Apollo !!!!!!!!!!!!!!!!!!!!!!!



Vue.use(VeeValidate);
Vue.use(VueAxios, axios);
Vue.use(Vuetify);
Vue.use(Editor);



// if user change localstorage
window.addEventListener('storage', () => {
    localStorage.removeItem('user');
    window.location.href='/login';
});



const app = new Vue({
    el: '#app',
     router,
     // qraphql,
     store,
     apolloProvider,
     render: h => h(App),
     data () {
        return {
            breadcrumbs: []
        }
     }
});


