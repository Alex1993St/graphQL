<template>
    <v-snackbar
        v-model="snackbar"
        :timeout="timeout"
        :color="color"
    >
        {{ text }}
        <v-btn
            flat
            color="danger"
            @click="snackbar = false"
        >
            Close
        </v-btn>
    </v-snackbar>
</template>

<script>
    export default {
            name: "Snackbar",

            props: {
                text: String,
                color: {type: String, default: 'error'},
                show: Boolean,
                timeout: Number
            },

            data: () => ({
            mode: '',
            snackbar: false
        }),

        watch: {
            show(value) {
                this.snackbar = value;
            }
        }
    }
</script>

<style scoped></style>
