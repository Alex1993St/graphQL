<template>
    <v-flex xs12 p-3>
        <v-flex  v-if="checkData">
            <v-flex xs12 sm12 v-if="list.status">
                    <h2> {{ list.title }}</h2>
                    <div class="row flex-wrap">
                        <div
                            class="flex xs12 md4 p-2"
                            v-for="(item,idx) in list.article" :key="idx"
                            xs12
                        >
                            <v-card class="elevation-2">
                                <v-card-title class="align-start flex-column">
                                    <h1 class="headline mb-0">{{ item.title }}</h1>
                                    <h2 class="headline mb-0">{{ item.short}}</h2>
                                </v-card-title>
                                <v-divider></v-divider>
                                <v-card-actions>
                                    <router-link :to="{ path: '/dashboard/' + item.slug}" replace class="v-btn v-btn--router theme--light primary">More</router-link>
                                </v-card-actions>
                            </v-card>
                        </div>
                    </div>
            </v-flex>
            <v-flex v-else>
                <v-btn color="primary" @click="back">You dont get access to this page</v-btn>
            </v-flex>
        </v-flex>
        <v-flex v-else>
                <v-flex xs12 md6 mb-4 offset-md3>
                <v-card class="elevation-2 p-4" >
                        <v-flex>
                           <h2>Category is empty</h2>
                        </v-flex>
                        <v-flex>
                            <v-btn color="primary" @click="back">Back</v-btn>
                        </v-flex>
                </v-card>
            </v-flex>
        </v-flex>
        <Preloader
            :value="preload.state"
            :message="preload.message"
            :progressColor="preload.color"
        ></Preloader>
    </v-flex>
</template>

<script>
    import Preloader from '../elements/preloader.vue';

    export default {
        components: {Preloader},
        data() {
            return {
                preload: {
                    state: true,
                    message: 'fetching data',
                    color: 'gray'
                },
                list: [],
                checkData: true
            }
        },
        methods:{
            back(){
                this.$router.go(-1)
            },

            init(){
                let vm = this;
                vm.preload.state = true;
                vm.axios.get('/api/list/' + vm.$route.params.title).then(function(res){
                    vm.list = res.data[0];
                    if(vm.list.article.length > 0) vm.checkData =  true;
                    else vm.checkData =  false;
                    vm.preload.state = false;
                }).catch(function(err){
                    vm.preload.state = false;
                    console.log(err);
                })
            },

            bread(){
                let params = this.$route.params.title;

                this.$root.breadcrumbs = [
                    {
                        text: 'Dashboard',
                        disabled: false,
                        href: '/dashboard'
                    },
                    {
                        text: params,
                        disabled: true
                    }
                ]
            }
        },

        beforeRouteUpdate (to, from, next) {
            next();
            this.init(to.params.title);
            this.bread();
        },

        created() {
            this.init();
            this.bread();
        },

    }
</script>

<style scoped>
    .headline {
        word-break: break-all;
    }
    .fade-enter-active {
        transition: all 0.6s ease-in;
    }

    .fade-leave-active {
        transition: all 0.6s ease-in;
    }

    .fade-enter, .fade-leave-to {
        opacity: 0;
    }
</style>
