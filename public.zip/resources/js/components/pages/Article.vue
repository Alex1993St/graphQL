<template>
    <v-flex xs12 p-3>
            <v-card>
                <v-toolbar flat color="white">
                    <v-toolbar-title>Articles</v-toolbar-title>
                    <v-spacer></v-spacer>
                    <v-text-field
                        v-model="search"
                        append-icon="search"
                        label="Search"
                        single-line
                        hide-details
                    ></v-text-field>
                    <v-btn color="primary" dark class="mb-2" @click="showItem('addNewArticle')" >New Articles</v-btn>
                </v-toolbar>
                <v-data-table
                    :headers="headers"
                    :items="articlesList"
                    class="elevation-1"
                    :search="search"
                    :rows-per-page-items="rowsPerPageItems"
                    :pagination.sync="pagination"
                >
                    <template v-slot:items="props">
                        <td>{{ props.item.id }}</td>
                        <td class="text-xs-left">{{ props.item.title }}</td>
                        <td class="text-xs-left">{{ rewrite(props.item.status) }}</td>
                        <td class="text-xs-left text" v-html="props.item.short">{{ props.item.short }}</td>
                        <td class="text-xs-left">{{ props.item.meta_title }}</td>
                        <td class="text-xs-left">{{ props.item.meta_description }}</td>
                        <td class="text-xs-left">{{ props.item.meta_keywords }}</td>
                        <td class="text-xs-left">{{ rewrite_access(props.item.only) }}</td>
                        <td class="justify-left align-center  layout px-0">
                            <v-icon
                                small
                                class="mr-2"
                                @click="showItem(props.item.id)"
                            >
                                edit
                            </v-icon>
                            <v-icon
                                small
                                @click="deleteItem(props.item)"
                            >
                                delete
                            </v-icon>
                        </td>
                    </template>
                    <warning></warning>
                </v-data-table>
            </v-card>
        </v-flex>
</template>

<script>
    import {APIService} from '../../APIService';
    import Warning from '../elements/warning.vue';
    import { mapState } from 'vuex';

    const apiService = new APIService();

    export default {
        data(){
            return {
                rowsPerPageItems: [10, 20, 30, 40],
                pagination: {
                    rowsPerPage: 10,
                    descending: true
                },
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                headers: [
                    {text: 'Id', align: 'left', value: 'id'},
                    {text: 'Title', value: 'title'},
                    {text: 'Status', value: 'status'},
                    {text: 'Short', value: 'short'},
                    {text: 'meta_title', value: 'meta_title'},
                    {text: 'meta_description', value: 'meta_description'},
                    {text: 'meta_keywords', value: 'meta_keywords'},
                    {text: 'only', value: 'only'},
                    {text: 'Action', sortable: false}
                ],
                article: [],
                items: [
                    {
                        id: "0",
                        status: 'not active'
                    },
                    {
                        id: "1",
                        status: 'active'
                    }
                ],
                access: [
                    {
                        id: "0",
                        status: 'all'
                    },
                    {
                        id: "1",
                        status: 'vip'
                    }
                ],
                userRole: '',
                dialog: false,
                author: [],
                search: ''
            }
        },

        components: {
            Warning
        },

        computed: {
            loading(){
                return this.$store.getters.LOAD
            },

            articlesList() {
                return this.$store.getters.ARTICLES
            },

            ...mapState(['isLoading'])
        },

        watch: {
            isLoading(newValue){
                if(newValue  == true){
                    this.alert = true;
                }else{
                    this.alert = false;
                }
            },
        },

        created () {
             this.fetchCategory();

             this.getArticlesList();

             this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: 'Articles',
                    disabled: true
                }
            ];
        },

        filters: {
            truncate: function(value) {
                let length = 15;
                if (value.length <= length) {
                    return value;
                } else {
                    return value.substring(8, length) + '...';
                }
            }
        },
        methods: {
            getArticlesList(){
                return this.$store.dispatch('GET_ARTICLES')
            },

            rewrite(item){
                return item == 1 ? 'active' : 'not active';
            },

            rewrite_access(item){
                return item == 1 ? 'vip' : 'all';
            },

            fetchCategory()
            {
                let vm  = this;
                 apiService.getCategories().then(function (response) {
                    vm.cat = response;
                }).catch(function (error) {
                    console.log(error, 404);
                })
            },

            showItem (item) {
                this.$router.push('/article/' + item);
            },

            delArticle(id){
                return this.$store.dispatch('DELETE_ARTICLE', id)
            },

            deleteItem (item) {
                let vm = this;
                if(confirm('Are you sure you want to delete this item?')){
                    apiService.deleteArticle(item.id).then((r)=>{
                        if(r.status === 200) vm.delArticle(item.id);
                    })
                }
            },
        }
    }
</script>

<style scoped>
    .text p img {
        width: 500px;
    }
</style>
