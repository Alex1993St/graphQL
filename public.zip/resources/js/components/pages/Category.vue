<template>
    <v-flex xs12 p-3>
        <v-card>
            <v-toolbar flat color="white">
                <v-toolbar-title>Categories</v-toolbar-title>
                <v-spacer></v-spacer>
                <v-text-field
                    v-model="search"
                    append-icon="search"
                    label="Search"
                    single-line
                    hide-details
                ></v-text-field>
                <v-dialog v-model="dialog" max-width="500px">
                    <template v-slot:activator="{ on }">
                        <v-btn color="primary" dark class="mb-2"  @click="dialog = !dialog" v-on="on">New Category</v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ formTitle }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container grid-list-md>
                                <v-layout wrap>
                                    <v-flex xs12 md12>
                                        <v-text-field v-validate="'required'" v-model="editedItem.title" data-vv-name="title" name="title" label="Title" :error-messages="errors.collect('title')"></v-text-field>
                                    </v-flex>
                                    <v-flex xs12 sm6 md6>
                                        <v-select v-validate="'required'"  item-text="status" item-value="id" :items="items" v-model="editedItem.status"  label="Status" name="status" data-vv-name="status" :error-messages="errors.collect('status')"></v-select>
                                    </v-flex>
                                    <v-flex xs12 sm6 md6>
                                        <v-select v-validate="'required'"  item-text="title" item-value="id"  :items="item" v-model="editedItem.parent_category" data-vv-name="parent_category" name="parent_category" label="Parent Category" :error-messages="errors.collect('parent_category')"></v-select>
                                     </v-flex>
                                </v-layout>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" flat @click="close">Cancel</v-btn>
                            <v-btn color="blue darken-1" flat @click="save">Save</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-toolbar>
            <v-data-table
                :headers="headers"
                :items="categoryList"
                class="elevation-1"
                :pagination.sync="pagination"
                :search="search"
                :rows-per-page-items="rppi"
                :loading="loading"
            >
                <template v-slot:items="props">
                    <td>{{ props.item.id }}</td>
                    <td class="text-xs-left">{{ props.item.title }}</td>
                    <td class="text-xs-left">{{ rewrite(props.item.status)}}</td>
                    <td class="text-xs-left">{{ props.item.parent_category }}</td>
                    <td class="justify-left align-center layout px-0">
                        <v-icon
                            small
                            class="mr-2"
                            @click="editItem(props.item)"
                        >
                            edit
                        </v-icon>
                        <v-icon
                            small
                            @click="deleteItem(props.item)"
                        >
                            delete
                        </v-icon>
                    </td>
                </template>
                <v-alert v-slot:no-results :value="true" color="error" icon="warning">
                    Your search for "{{ search }}" found no results.
                </v-alert>
            </v-data-table>
        </v-card>
    </v-flex>
</template>

<script>
    import {APIService} from '../../APIService';
    import { mapState } from 'vuex';

    const apiService = new APIService();

    export default {
        data(){
            return {
                rppi: [10,20,30],
                search: '',
                pagination: {
                    descending: true,
                },
                csrf: window.axios.defaults.headers.common['X-CSRF-TOKEN'],
                headers: [
                    { text: 'Id', align: 'left', value: 'id', sort: 'desc'},
                    { text: 'Title', value: 'title' },
                    { text: 'Status', value: 'status' },
                    { text: 'Parent Category', value: 'parent_category'},
                    { text: 'Action', sortable: false }
                ],
                category: [],
                editedItem: {
                    title: '',
                    status: '',
                    parent_category: 0
                },
                item: [],
                items: [
                    {
                        id: "0",
                        status: 'not active'
                    },
                    {
                        id: "1",
                        status: 'active'
                    }
                ],
                userRole: '',
                dialog: false,
                editedIndex: -1,
            }
        },

        computed: {
            formTitle () {
                return this.editedIndex === -1 ? 'New Category' : 'Edit Category'
            },

            categoryList(){
                return this.item = this.$store.getters.CATEGORIES;
            },

            loading(){
                return this.$store.getters.LOAD
            },

            ...mapState(['isLoading'])
        },

        watch: {
            isLoading(newValue){
                if(newValue){
                    this.alert = true;
                }else{
                    this.alert = false;
                }
            },

            dialog (val) {
                val || this.close()
            },
        },

        created () {
            this.getCategory();

            this.$root.breadcrumbs = [
                {
                    text: 'Dashboard',
                    disabled: false,
                    href: '/dashboard'
                },
                {
                    text: 'Categories',
                    disabled: true
                }
            ];
        },

        methods: {
            getCategory() {
                return this.$store.dispatch('GET_CATEGORIES', this.editedItem);
            },

            rewrite(item){
               return item == 1 ? 'active' : 'not active';
            },

            editItem (item) {
                this.editedIndex = 1;
                this.editedItem = Object.assign({}, item);
                this.dialog = true;
            },

            deleteItem (item) {
                let vm = this;
                if(confirm('Are you sure you want to delete this item?')){
                    apiService.deleteCategory(item.id).then((r)=>{
                        if(r.status === 200) vm.delCategory(item.id);
                    })
                }
            },

            close () {
                this.dialog = false;
                setTimeout(() => {
                    this.editedItem = Object.assign({}, '')
                    this.editedIndex = -1
                }, 300)
            },

            saveCategory(){
                return this.$store.dispatch('SAVE_CATEGORY', this.editedItem)
            },

            editCategory(){
                return this.$store.dispatch('EDIT_CATEGORY', this.editedItem)
            },

            delCategory(id){
                return this.$store.dispatch('DELETE_CATEGORY', id);
            },

            save () {
                let vm = this;
                vm.editedItem.id ? vm.editedItem.id : vm.editedItem.id = '';
                vm.$validator.validateAll().then((result) => {
                    if(result){
                        this.close()
                        vm.editedIndex === -1 ? vm.saveCategory() : vm.editCategory();
                    }
                });

            }
        }
    }
</script>

