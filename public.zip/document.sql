-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.23 - MySQL Community Server (GPL)
-- Операционная система:         Win32
-- HeidiSQL Версия:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица document.articles
CREATE TABLE IF NOT EXISTS `articles` (
  `id` bigint(20) unsigned NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `short` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `full` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keywords` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `only` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_id` int(11) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.articles: ~0 rows (приблизительно)
DELETE FROM `articles`;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` (`id`, `title`, `status`, `slug`, `category_id`, `short`, `full`, `meta_title`, `meta_description`, `meta_keywords`, `only`, `user_id`, `created_at`, `updated_at`) VALUES
	(8, 'Start streaming', '1', 'start-streaming-140156', 24, 'Информация по запуску трансляции находится', '<p><span style="color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Информация по запуску трансляции находится в&nbsp;</span><a style="box-sizing: border-box; outline: none; color: #2962ff; text-decoration-line: none; background-color: #eeeeee; font-family: \'Nunito Sans\', sans-serif; font-size: 14px;" href="https://docs.google.com/presentation/d/1xOyP6oqa5JN3ezLU_c0m7KDJj8Fsb9zklrYcHEcG01o/edit?usp=sharing">презентации&nbsp;</a></p>', 'Start streaming', 'Start streaming', 'Start streaming', '0', 2, '2019-05-17 04:51:51', '2019-05-20 11:01:56'),
	(9, 'Пиксель интеграция 5577', '1', 'piksel-integratsiya-5577-075237', 12, 'Ответственный афилиейт менеджер - Viktor Simmons', '<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">1. сохраняем в бд параметр(click_id)&nbsp;при регистрации если совпадает id партнера&nbsp;5577.</p>\n<pre style="box-sizing: border-box; outline: none; font-family: SFMono-Regular, Menlo, Monaco, Consolas, \'Liberation Mono\', \'Courier New\', monospace; font-size: 12.25px; margin-top: 0px; margin-bottom: 1rem; overflow: auto; color: #212529; background-color: #eeeeee;">if (isset($_GET[\'a_aid\']) &amp;&amp; $_GET[\'a_aid\'] == 5577 &amp;&amp; isset($_GET[\'subid\'])) {\n    $click_id = isset($_GET[\'subid\']) ? $_GET[\'subid\'] : null;\n}</pre>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">2. делаем колбек запрос после регистрации и подтверждения почты:<br style="box-sizing: border-box; outline: none;" />файл в корне confirm.php:<br style="box-sizing: border-box; outline: none;" />&nbsp;</p>\n<pre style="box-sizing: border-box; outline: none; font-family: SFMono-Regular, Menlo, Monaco, Consolas, \'Liberation Mono\', \'Courier New\', monospace; font-size: 12.25px; margin-top: 0px; margin-bottom: 1rem; overflow: auto; color: #212529; background-color: #eeeeee;">if ($row[\'bid\'] == 5577) {\n    $ch = curl_init();\n    curl_setopt($ch, CURLOPT_URL, "http://postback.kadam.net/ru/postback/?data={$row[\'click_id\']}");\n    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);\n    $result = curl_exec($ch);\n    if (strpos($result, \'ok\') !== false) {\n        $newNote = $user[\'note\'].\' | \'.\'register event sent \'.date("Y-m-d H:i:s");\n        $db-&gt;query("UPDATE dle_users SET note = \'{$newNote}\' WHERE tm_userid = {$row[\'tm_userid\']}");\n    }\n}</pre>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">&nbsp;</p>\n<hr style="box-sizing: content-box; outline: none; height: 0px; overflow: visible; margin-top: 1rem; margin-bottom: 1rem; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-image: initial; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee; border-color: rgba(0, 0, 0, 0.1) initial initial initial;" />\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Саппорт менеджр Кадам предоставил следущую информацию:<br style="box-sizing: border-box; outline: none;" />"</p>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Если действий несколько и нужно их разделять по статусам, например, регистрация со статусом "холд", а депозит со статусом "аппрув", тогда в постбек еще добавляется дополнительный параметр status</p>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">&amp;status=hold - лид в "холде"<br style="box-sizing: border-box; outline: none;" />&amp;status=approved - лид подтвержден<br style="box-sizing: border-box; outline: none;" />&amp;status=reject - лид отклонен</p>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Или если у вас есть своя метка для передачи статуса, то можно указать ее и просто нам сообщить какие значения эта метка при каждом статусе принимает.<br style="box-sizing: border-box; outline: none;" /><br style="box-sizing: border-box; outline: none;" />Тогда аффилейтам, которые будут настраивать уведомление о конверсии, достаточно указать метку в выдаваемых им рекламируемых ссылках и указать в вашем интерфейсе нужный постбек http://postback.kadam.net/ru/postback/?data={subid} на нужное целевое действие. Опять же обращаем внимание, что если нужно настроить постбек на несколько целевых действий (например, регистрация и депозит, где регистрация не оплачивается, например, а депозит оплачивается), то рекомендуется использование переменной статуса status.<br style="box-sizing: border-box; outline: none;" />Т.е. тогда нужно будет указать 2 постбека:<br style="box-sizing: border-box; outline: none;" />со статусом "в работе" на регистрацию - http://postback.kadam.net/ru/postback/?data={subid}&amp;status=hold<br style="box-sizing: border-box; outline: none;" />со татусом "ОК" на депозит - http://postback.kadam.net/ru/postback/?data={subid}&amp;status=approved</p>\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">"</p>\n<hr style="box-sizing: content-box; outline: none; height: 0px; overflow: visible; margin-top: 1rem; margin-bottom: 1rem; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-image: initial; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee; border-color: rgba(0, 0, 0, 0.1) initial initial initial;" />\n<p style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Пожалуйста, предоставьте вашей партнерке эту инструкцию https://wiki.kadam.net/index.php?title=Настройка_postback_для_СРА</p>', 'Пиксель интеграция 5577', 'Пиксель интеграция 5577', 'Пиксель интеграция 5577', '0', 3, '2019-05-17 04:52:37', '2019-05-17 04:52:37'),
	(10, 'Страница Депозит', '1', 'stranitsa-depozit-075311', 12, 'Тут будет описание текущей логики депозит страницы', '<p><span style="color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Тут будет описание текущей логики депозит страницы</span></p>', 'Страница Депозит', 'Страница Депозит', 'Страница Депозит', '0', 3, '2019-05-17 04:53:11', '2019-05-17 04:53:11'),
	(11, 'ПСП на странице депозита BO', '1', 'psp-na-stranitse-depozita-bo-075346', 12, 'ПСП на странице депозита BO', '<p><a href="https://docs.google.com/spreadsheets/d/1DpSL4kTrplxiChU53lI9rtiWby-ECSKW6OeAYAFks4Y/edit#gid=8534877">https://docs.google.com/spreadsheets/d/1DpSL4kTrplxiChU53lI9rtiWby-ECSKW6OeAYAFks4Y/edit#gid=8534877</a></p>', 'ПСП', 'ПСП', 'ПСП', '0', 4, '2019-05-17 04:53:46', '2019-05-17 04:53:46'),
	(12, 'Пиксель интеграция 5577', '1', 'piksel-integratsiya-5577-075431', 13, 'Пиксель интеграция 5577', '<p><span style="color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Все сделано аналогично БО, описание смотри здесь: http://promo.24bio.com/admin/blog/article/piksel-integratsiya-5577-21080855</span></p>', 'Пиксель интеграция 5577', 'Пиксель интеграция 5577', 'Пиксель интеграция 5577', '0', 3, '2019-05-17 04:54:31', '2019-05-17 04:54:31'),
	(13, 'ПСП на странице депозита FX', '1', 'psp-na-stranitse-depozita-fx-075455', 13, 'ПСП на странице депозита FX', '<p><a style="box-sizing: border-box; outline: none; color: #2962ff; text-decoration-line: none; background-color: #eeeeee; font-family: \'Nunito Sans\', sans-serif; font-size: 14px;" href="https://docs.google.com/spreadsheets/d/1AOn3x8C9CJluGkfz7GsrIdUxx68AKhmlz6-FyNJFc0I/edit?usp=sharing">https://docs.google.com/spreadsheets/d/1AOn3x8C9CJluGkfz7GsrIdUxx68AKhmlz6-FyNJFc0I/edit?usp=sharing</a></p>', 'ПСП на странице депозита FX', 'ПСП на странице депозита FX', 'ПСП на странице депозита FX', '0', 4, '2019-05-17 04:54:55', '2019-05-17 04:54:55'),
	(14, 'TikTok Landings', '1', 'tiktok-landings-144248', 14, 'TikTok Landings', '<p><a href="http://buytiktoklikes.com/">http://buytiktoklikes.com/</a></p>', 'TikTok Landings', 'TikTok Landings', 'TikTok Landings', '0', 9, '2019-05-17 04:56:33', '2019-05-28 11:42:48'),
	(16, 'BO Landings', '1', 'bo-landings-075757', 15, 'BO Landings', '<p><a href="https://docs.google.com/spreadsheets/d/15aD7duJKg2q85YNWb3S3-IeArhYx1TJ6wBmmysJCgFE/edit">https://docs.google.com/spreadsheets/d/15aD7duJKg2q85YNWb3S3-IeArhYx1TJ6wBmmysJCgFE/edit</a></p>', 'BO Landings', 'BO Landings', 'BO Landings', '0', 4, '2019-05-17 04:57:57', '2019-05-17 04:57:57'),
	(17, 'FX landings', '1', 'fx-landings-075825', 16, 'FX landings', '<p><a href="https://docs.google.com/spreadsheets/d/1AXAKhXpryRr4GZVjyn3PA9QHcCim8E4PFLf7sNdYsGo/edit">https://docs.google.com/spreadsheets/d/1AXAKhXpryRr4GZVjyn3PA9QHcCim8E4PFLf7sNdYsGo/edit</a></p>', 'FX landings', 'FX landings', 'FX landings', '0', 4, '2019-05-17 04:58:25', '2019-05-17 04:58:25'),
	(18, 'CFD landings', '1', 'cfd-landings-075849', 17, 'CFD landings', '<p><a href="https://docs.google.com/spreadsheets/d/1tyyJ-XLIg50DL34AEhqjOF0MZvXWLohe-o6V_2saNoY/edit">https://docs.google.com/spreadsheets/d/1tyyJ-XLIg50DL34AEhqjOF0MZvXWLohe-o6V_2saNoY/edit</a></p>', 'CFD landings', 'CFD landings', 'CFD landings', '0', 4, '2019-05-17 04:58:49', '2019-05-17 04:58:49'),
	(19, 'ПСП на странице депозита CFD', '1', 'psp-na-stranitse-depozita-cfd-075915', 18, 'ПСП на странице депозита CFD', '<p><a href="https://docs.google.com/spreadsheets/d/1LBFe_Gprpe_mJ3hlBRdO1O8UjH31cIGHlkKODLyOHow/edit#gid=0">https://docs.google.com/spreadsheets/d/1LBFe_Gprpe_mJ3hlBRdO1O8UjH31cIGHlkKODLyOHow/edit#gid=0</a></p>', 'ПСП на странице депозита CFD', 'ПСП на странице депозита CFD', 'ПСП на странице депозита CFD', '0', 4, '2019-05-17 04:59:15', '2019-05-17 04:59:15'),
	(20, 'Backend Codestyle', '1', 'backend-codestyle-114002', 19, 'Backend Codestyle', '<p><span style="color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Информация будет добавлена скоро</span></p>', 'Backend Codestyle', 'Backend Codestyle', 'Backend Codestyle', '0', 9, '2019-05-17 04:59:42', '2019-05-27 08:40:02'),
	(21, 'Frontend Codestyle', '1', 'frontend-codestyle-080002', 19, 'Frontend Codestyle', '<p><span style="color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">Писать надо хорошо! Проверю)</span></p>', 'Frontend Codestyle', 'Frontend Codestyle', 'Frontend Codestyle', '0', 3, '2019-05-17 05:00:02', '2019-05-17 05:00:02'),
	(22, 'Документацию надо писать', '1', 'dokumentatsiyu-nado-pisat-080038', 21, 'Документацию надо писать', '<ol style="box-sizing: border-box; outline: none; margin-top: 0px; margin-bottom: 1rem; color: #3e5569; font-family: \'Nunito Sans\', sans-serif; font-size: 14px; background-color: #eeeeee;">\n<li style="box-sizing: border-box; outline: none; margin: 5px 0px;">Пишем тут документацию&nbsp;по каждой новой сложной задаче.</li>\n<li style="box-sizing: border-box; outline: none; margin: 5px 0px;">По возможности документируем уже созданный функционал.</li>\n</ol>', 'Документацию надо писать', 'Документацию надо писать', 'Документацию надо писать', '0', 3, '2019-05-17 05:00:38', '2019-05-17 05:00:38'),
	(23, 'CRM automailers', '1', 'crm-automailers-080100', 22, 'CRM automailers', '<p><a href="https://drive.google.com/drive/folders/1ydOubUlVg2O4sNt5e59H2JamFxlIGcom">https://drive.google.com/drive/folders/1ydOubUlVg2O4sNt5e59H2JamFxlIGcom</a></p>', 'CRM automailers', 'CRM automailers', 'CRM automailers', '0', 4, '2019-05-17 05:01:00', '2019-05-17 05:01:00'),
	(24, 'Landings 24 BIO', '1', 'landings-24-bio-121149', 23, 'Landings 24 BIO', '<p><a href="https://docs.google.com/spreadsheets/d/1Emsgqv2N6zqqISb3nhTJWxR9OkKLn_a3oKLYCUq2ybM/edit">https://docs.google.com/spreadsheets/d/1Emsgqv2N6zqqISb3nhTJWxR9OkKLn_a3oKLYCUq2ybM/edit</a></p>', 'Landings 24 BIO', 'Landings 24 BIO', 'Landings 24 BIO', '0', 9, '2019-05-17 05:01:28', '2019-05-28 09:11:49');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;

-- Дамп структуры для таблица document.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_category` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.categories: ~13 rows (приблизительно)
DELETE FROM `categories`;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `title`, `slug`, `status`, `parent_category`, `created_at`, `updated_at`) VALUES
	(12, 'FinmaxBo', 'finmaxbo-071738', '1', 0, '2019-05-17 04:38:17', '2019-05-17 04:38:17'),
	(13, 'FinmaxFx', 'finmaxfx-073138', '1', 0, '2019-05-17 04:38:31', '2019-05-17 04:38:31'),
	(14, 'MusicallyPo/FreeTikTok', 'musicallypofreetiktok-070839', '1', 0, '2019-05-17 04:39:08', '2019-05-17 04:39:08'),
	(15, 'LandingsBo', 'landingsbo-075439', '1', 0, '2019-05-17 04:39:54', '2019-05-17 04:39:54'),
	(16, 'LandingsFX', 'landingsfx-071040', '1', 0, '2019-05-17 04:40:10', '2019-05-17 04:40:10'),
	(17, 'LandingCFD', 'landingcfd-073440', '1', 0, '2019-05-17 04:40:34', '2019-05-17 04:40:34'),
	(18, 'FinmaxCFD', 'finmaxcfd-074940', '1', 0, '2019-05-17 04:40:49', '2019-05-17 04:40:49'),
	(19, 'General Codestyle', 'general-codestyle-070341', '1', 0, '2019-05-17 04:41:03', '2019-05-17 04:41:03'),
	(20, 'QA docs', 'qa-docs-071741', '1', 0, '2019-05-17 04:41:17', '2019-05-17 04:41:17'),
	(21, 'Other', 'other-073141', '1', 0, '2019-05-17 04:41:31', '2019-05-17 04:41:31'),
	(22, 'TradesMaster', 'tradesmaster-074341', '1', 0, '2019-05-17 04:41:43', '2019-05-17 04:41:43'),
	(23, '24 BIO', '24-bio-075341', '1', 0, '2019-05-17 04:41:53', '2019-05-17 04:41:53'),
	(24, 'Youtube live streamin', 'youtube-live-streamin-085139', '1', 12, '2019-05-17 04:42:33', '2019-05-28 05:39:51');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Дамп структуры для таблица document.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.migrations: ~5 rows (приблизительно)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_05_08_062729_create_categories_table', 1),
	(4, '2019_05_08_063301_create_articles_table', 1),
	(5, '2019_05_30_121106_create_wines_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Дамп структуры для таблица document.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.password_resets: ~0 rows (приблизительно)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Дамп структуры для таблица document.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0',
  `only` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.users: ~7 rows (приблизительно)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `only`, `created_at`, `updated_at`) VALUES
	(1, 'ALex', 'test@i.ua', '2019-05-30 15:19:05', '$2y$10$NiUWfa/IzzQDzgP/XTxqb./MA0YPVrPV256asVE4VZ3.ttZ4NBIbm', NULL, 3, '0', '2019-05-30 15:19:19', '2019-05-30 15:19:19'),
	(2, 'AlexGusto', 'alexgusto.finmax@gmail.com', NULL, '$2y$10$NiUWfa/IzzQDzgP/XTxqb./MA0YPVrPV256asVE4VZ3.ttZ4NBIbm', NULL, 3, '0', '2019-05-17 04:48:47', '2019-05-17 04:48:47'),
	(4, 'Mariana', 'marianatest11@gmail.com', NULL, '$2y$10$a46NpadXpdnGohnE5Rkq8.hQntYQHl/8vXK6IJjVRn/bdM8cWZ/4W', NULL, 3, '0', '2019-05-17 04:49:54', '2019-05-17 04:49:54'),
	(8, 'Visitor', 'visitor@email.com', NULL, '$2y$10$XKVpyuTLBHHMrESqBZ1rm.2RQRxKR5B1vfvxR0s52pjHsRHBZm7Vu', NULL, 3, '0', '2019-05-20 10:12:38', '2019-05-20 10:12:38'),
	(9, 'Admin', 'admin@email.com', NULL, '$2y$10$4Nu3A/IF1AzHsHdVxHxIHuJ3mNZbUjKTaKj9hjvM0BCgb/2MS/Ala', NULL, 3, '0', '2019-05-20 10:12:53', '2019-05-20 10:12:53'),
	(10, 'Author', 'author@email.com', NULL, '$2y$10$.sBxpHbcZVk5w/R2AR3V5eXE6KmLl6I15klGqz/hIlMzeHaPEAuey', NULL, 2, '0', '2019-05-20 10:13:06', '2019-05-20 10:13:06'),
	(12, 'Oleksandr', 'qa.gudz@gmail.com', NULL, '$2y$10$FSGvS8.Ksvn23bNbJ2mFhuXchFQub9eAZ2DpaIC70j3MfLXDboR7.', NULL, 3, '0', '2019-05-20 10:13:40', '2019-05-20 10:13:40');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Дамп структуры для таблица document.wines
CREATE TABLE IF NOT EXISTS `wines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grape_variety` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы document.wines: ~5 rows (приблизительно)
DELETE FROM `wines`;
/*!40000 ALTER TABLE `wines` DISABLE KEYS */;
INSERT INTO `wines` (`id`, `name`, `description`, `color`, `grape_variety`, `country`, `created_at`, `updated_at`) VALUES
	(1, 'Classic', 'A medium-bodied', 'red', 'Sanfiovese', 'Italy', '2019-05-30 12:18:04', '2019-05-30 12:18:04'),
	(2, 'Bordeaux', 'A wine with fruit scents and flavors of blackberry, dark cherry, vanilla, coffee bean, and licorice. The wines are often concentrated, powerful, firm and tannic', 'red', 'Merlot', 'France', '2019-05-30 12:18:04', '2019-05-30 12:18:04'),
	(3, 'White Zinfandel', 'Often abbreviated as White Zin, it is a dry to sweet wine, pink-colored rosé', 'rosé', 'Zinfandel', 'USA', '2019-05-30 12:18:04', '2019-05-30 12:18:04'),
	(4, 'Port', 'A fortified sweet red wine, often served as a dessert wine', 'red', 'Touriga Nacional', 'Portugal', '2019-05-30 12:18:04', '2019-05-30 12:18:04'),
	(5, 'Prosecco', 'It is a dry white wine (brut) sometimes with a sweet flavor of green apple, honeydew melon, pear, and honeysuckle', 'white', 'Glera', 'Italy', '2019-05-30 12:18:04', '2019-05-30 12:18:04');
/*!40000 ALTER TABLE `wines` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
